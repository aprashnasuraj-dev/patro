export default {
  async scheduled(controller, env, ctx) {
    ctx.waitUntil(runGate(env, "cron", controller.scheduledTime));
  },
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health") return Response.json({service:"AafnaiPatro Growth Gate",status:"ready",schedule:"*/30 * * * *"});
    if (url.pathname !== "/status") return new Response("Not found", {status:404});
    const rows = await env.DB.prepare("SELECT run_id,started_at,finished_at,trigger_type,overall_status,passed,failed FROM growth_gate_runs ORDER BY started_at DESC LIMIT 1").all();
    return Response.json({service:"AafnaiPatro Growth Gate",latest:rows.results?.[0] || null});
  }
};

async function runGate(env, triggerType, scheduledTime) {
  const started = new Date().toISOString();
  const runId = crypto.randomUUID();
  const targets = [
    {key:"homepage",path:"/",marker:"data-patro-discovery-v2"},
    {key:"nepalmap",path:"/nepalmap"},
    {key:"nepal-guide",path:"/nepal"},
    {key:"tools",path:"/tools",marker:"data-patro-discovery-v2"},
    {key:"atlas",path:"/atlas",marker:"data-patro-discovery-v2"},
    {key:"rashifal",path:"/rashifal"},
    {key:"ads-home",path:"/",markers:["id=\"patro-native-ad-slot\"","https://bauval.org/21/b86f7b1b852ea7f8de7539079e6e7816","https://bauval.org/14/d526bb158baa587de984d6036f99adaf","https://araplhn.org/4/c752b529eb7d6d4ebf1096d225dfb10a","https://abscloud.org/1/fe7eda2cd06bda210f4e85075df3069c"]},
    {key:"ads-converter",path:"/tools/bstoad",markers:["id=\"patro-native-ad-slot\"","https://bauval.org/21/b86f7b1b852ea7f8de7539079e6e7816","https://bauval.org/14/d526bb158baa587de984d6036f99adaf","https://araplhn.org/4/c752b529eb7d6d4ebf1096d225dfb10a","https://abscloud.org/1/fe7eda2cd06bda210f4e85075df3069c"]},
    {key:"ads-rashifal",path:"/rashifal",markers:["id=\"patro-native-ad-slot\"","https://bauval.org/21/b86f7b1b852ea7f8de7539079e6e7816","https://bauval.org/14/d526bb158baa587de984d6036f99adaf","https://araplhn.org/4/c752b529eb7d6d4ebf1096d225dfb10a","https://abscloud.org/1/fe7eda2cd06bda210f4e85075df3069c"]},
    {key:"bs-to-ad",path:"/tools/bstoad"},
    {key:"ad-to-bs",path:"/tools/adtobs"},
    {key:"on-this-day",path:"/on-this-day"},
    {key:"moon",path:"/moon"},
    {key:"eclipse",path:"/eclipse"},
    {key:"trek-weather",path:"/nepal/trek-weather"},
    {key:"robots",path:"/robots.txt",marker:"Sitemap:"},
    {key:"sitemap-index",path:"/sitemap.xml",marker:"sitemap"},
    {key:"llms",path:"/llms.txt",marker:"aafnaipatro.com"},
    {key:"ai-policy",path:"/ai.txt",marker:"aafnaipatro.com"},
    {key:"agents",path:"/.well-known/agents.json",marker:""},
    {key:"mcp",path:"/mcp",marker:""}
  ];
  const checks = await Promise.all(targets.map(async target => {
    const checkedAt = new Date().toISOString();
    try {
      const response = await fetch("https://aafnaipatro.com"+target.path, {
        method:"GET",
        redirect:"follow",
        headers:{"User-Agent":"AafnaiPatro-Growth-Gate/1.0 (+https://aafnaipatro.com)","Accept":"text/html,application/json,text/plain,application/xml;q=0.9,*/*;q=0.8"}
      });
      let detail = response.ok ? "HTTP "+response.status : "HTTP "+response.status;
      let passed = response.status >= 200 && response.status < 400;
      if (target.marker || target.markers) {
        const body = await response.text();
        const expected = target.markers || [target.marker];
        const missing = expected.filter(marker => !body.toLowerCase().includes(marker.toLowerCase()));
        if (missing.length) { passed = false; detail += "; expected marker(s) missing: "+missing.join(", ").slice(0,400); }
        else detail += target.markers ? "; all "+expected.length+" ad placement markers present" : "; content marker present";
      } else if (response.body) {
        try { await response.body.cancel(); } catch {}
      }
      return {key:target.key,url:"https://aafnaipatro.com"+target.path,statusCode:response.status,passed,detail,checkedAt};
    } catch (error) {
      return {key:target.key,url:"https://aafnaipatro.com"+target.path,statusCode:null,passed:false,detail:String(error).slice(0,240),checkedAt};
    }
  }));
  const passed = checks.filter(c=>c.passed).length;
  const failed = checks.length-passed;
  const finished = new Date().toISOString();
  const overall = failed === 0 ? "PASS" : "ACTION_REQUIRED";
  await env.DB.prepare("INSERT INTO growth_gate_runs (run_id,started_at,finished_at,trigger_type,overall_status,passed,failed,result_json) VALUES (?,?,?,?,?,?,?,?)")
    .bind(runId,started,finished,triggerType,overall,passed,failed,JSON.stringify({scheduledTime:scheduledTime||null,checks})).run();
  const stmt = env.DB.prepare("INSERT INTO growth_gate_checks (run_id,check_key,url,status_code,passed,detail,checked_at) VALUES (?,?,?,?,?,?,?)");
  await env.DB.batch(checks.map(c=>stmt.bind(runId,c.key,c.url,c.statusCode,c.passed?1:0,c.detail,c.checkedAt)));
  await env.DB.prepare("DELETE FROM growth_gate_runs WHERE started_at < datetime('now','-30 days')").run();
  await env.DB.prepare("DELETE FROM growth_gate_checks WHERE checked_at < datetime('now','-30 days')").run();
}