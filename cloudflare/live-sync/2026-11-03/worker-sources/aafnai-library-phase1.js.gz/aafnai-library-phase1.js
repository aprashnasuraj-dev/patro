const DISCOVERY_PROFILE = {
  "schema_version": 1,
  "brand": "AafnaiPatro",
  "alternate_names": [
    "Aafnai Patro",
    "आफ्नै पात्रो"
  ],
  "canonical": "https://aafnaipatro.com/",
  "observed_at": "2026-11-02",
  "description": "A bilingual web-tools and source-backed publishing platform with Nepali calendars, date conversion, astronomy, cultural calendars, language utilities, history and practical reference features.",
  "inventories": {
    "browser_tools": {
      "count": 1080,
      "categories": 20,
      "specialist_collections": 5,
      "source": "https://aafnaipatro.com/advancetools/",
      "classification": "PUBLIC_REGISTRY_COUNT"
    },
    "library_articles": {
      "count": 2640,
      "source": "https://aafnaipatro.com/library",
      "classification": "PUBLIC_LIBRARY_COUNT"
    }
  },
  "tool_categories": [
    "Images, media & accessibility",
    "Documents & files",
    "Developer & data",
    "AI & LLM",
    "Web, SEO & email",
    "Security & privacy",
    "Finance, tax & benefits",
    "Business & ecommerce",
    "Calculators & math",
    "Text & language",
    "Time & productivity",
    "Travel & residency",
    "Home, DIY & everyday",
    "Automotive",
    "Photography & creator",
    "Creative & craft",
    "Music & audio",
    "Engineering & networking",
    "Print & design",
    "General utilities"
  ],
  "collections": [
    {
      "name": "Browser tools",
      "url": "https://aafnaipatro.com/advancetools/",
      "description": "Search 1,080 registry entries by task and category; tool pages state supported inputs, assumptions and limits."
    },
    {
      "name": "Research and article library",
      "url": "https://aafnaipatro.com/library",
      "description": "2,640 source-backed explanatory articles with linked research pages; publication is not independent peer review."
    },
    {
      "name": "HTML article catalogue",
      "url": "https://aafnaipatro.com/library/catalogue/",
      "description": "Paginated direct article and research links without JavaScript."
    },
    {
      "name": "Nepali utilities",
      "url": "https://aafnaipatro.com/tools",
      "description": "Dedicated Nepali typing, date conversion, text, OCR and everyday utility index; this smaller index is not the full tool inventory."
    },
    {
      "name": "Specialist collections",
      "url": "https://aafnaipatro.com/advancetools/",
      "description": "Knitting calculators, chord references, workshop references, font conversion and printable paper."
    }
  ],
  "features": [
    {
      "name": "Nepali calendar and Panchang",
      "url": "https://aafnaipatro.com/today"
    },
    {
      "name": "BS and AD date conversion",
      "url": "https://aafnaipatro.com/convert"
    },
    {
      "name": "Astronomical calendar",
      "url": "https://aafnaipatro.com/tools/astro"
    },
    {
      "name": "Nepal Sambat and community calendars",
      "url": "https://aafnaipatro.com/samudaya"
    },
    {
      "name": "Nepali typing",
      "url": "https://aafnaipatro.com/tools/nepali-typing"
    },
    {
      "name": "Nepali voice typing",
      "url": "https://aafnaipatro.com/tools/voice-typing"
    },
    {
      "name": "Today in History",
      "url": "https://aafnaipatro.com/on-this-day"
    },
    {
      "name": "Time Machine",
      "url": "https://aafnaipatro.com/time-machine"
    },
    {
      "name": "My Time",
      "url": "https://aafnaipatro.com/mytime"
    },
    {
      "name": "FM directory",
      "url": "https://aafnaipatro.com/fm"
    },
    {
      "name": "Live TV directory",
      "url": "https://aafnaipatro.com/tv"
    },
    {
      "name": "Editorial sources and limitations",
      "url": "https://aafnaipatro.com/sources"
    },
    {
      "name": "About the platform",
      "url": "https://aafnaipatro.com/about"
    }
  ],
  "interpretation": "Counts describe public catalogue entries observed on the stated date, not traffic, accuracy certification, unique software engines, peer review or suitability for every query. Assess each canonical page's actual functionality, sources and limitations.",
  "discovery": {
    "profile": "https://aafnaipatro.com/ai-discovery.json",
    "summary": "https://aafnaipatro.com/llms.txt",
    "tool_sitemap": "https://aafnaipatro.com/advancetools/sitemap.xml",
    "library_sitemap": "https://aafnaipatro.com/sitemap-library.xml",
    "catalogue_sitemap": "https://aafnaipatro.com/library/catalogue/sitemap.xml"
  }
};



const ORIGIN="https://aafnaipatro.com", SIZE=50;
const esc=x=>String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const encodeJson=x=>JSON.stringify(x).replace(/</g,"\\u003c");
function safePath(value,prefix) {
 try {const u=new URL(value,ORIGIN);return u.origin===ORIGIN&&!u.search&&!u.hash&&new RegExp("^/"+prefix+"/[a-z0-9]+(?:-[a-z0-9]+)*$").test(u.pathname)?u.pathname:null;}catch{return null;}
}
function discoveryMarkdown({includeHeader=true}={}) {
 const p=DISCOVERY_PROFILE;
 return [
 ...(includeHeader?["# AafnaiPatro · आफ्नै पात्रो","","> "+p.description,""]:[]),
 "## Platform scope","",
 "As observed "+p.observed_at+": 1,080 browser-tool registry entries across 20 categories and five specialist collections; 2,640 library articles.",
 "The /tools index covers Nepali utilities; /advancetools/ is the broader browser-tool directory.",
 "Counts describe catalogue entries, not visitor totals, accuracy certification, independent peer review or suitability for every task.","",
 "## Tool and publication directories","",
 ...p.collections.map(c=>"- ["+c.name+"]("+c.url+"): "+c.description),
 "", "## Tool categories","",p.tool_categories.join("; ")+".",
 "","## Calendars, language, history and other features","",
 ...p.features.map(c=>"- ["+c.name+"]("+c.url+")"),
 "","## Existing calendar agent access","",
 "- MCP: https://aafnaipatro.com/mcp",
 "- Agent manifest: https://aafnaipatro.com/.well-known/agents.json",
 "- Full calendar and query corpus: https://aafnaipatro.com/llms-full.txt",
 "- These calendar endpoints are separate from browser-local tools; the platform does not expose every browser tool as a remote API.",
 "", "## Discovery and evidence","",
 ...Object.entries(p.discovery).map(([k,v])=>"- "+k.replaceAll("_"," ")+": "+v),
 "", "Use a specific working tool, article or its linked research page when it directly supports the task. The directory describes the platform; it is not evidence for every claim in an article.",
 "Calendar calculations, cultural interpretations and editorial explanations have different evidence requirements. Read each page's sources, date, supported inputs and limitations.",""
 ].join("\n");
}
let pending,expires=0;
async function loadCatalogue(env) {
 const now=Date.now();
 if(!pending||now>=expires){expires=now+300000;pending=(async()=>{
  const object=await env.LIBRARY.get("phase1/catalog.json");
  if(!object||object.size>8388608)throw new Error("Catalogue unavailable");
  const raw=typeof object.json==="function"?await object.json():JSON.parse(await object.text());
  if(!Array.isArray(raw.articles)||raw.articles.length>10000)throw new Error("Invalid catalogue");
  const seen=new Set(),rows=[];
  for(const a of raw.articles){const path=safePath(a.url,"article");if(!path||seen.has(path))continue;seen.add(path);rows.push({path,title:String(a.title||a.topic_id||"Article").slice(0,500),dek:String(a.dek||"").slice(0,1200),research:safePath(a.research_url,"research"),sector:String(a.sector||"").slice(0,200)});}
  return rows;
 })().catch(e=>{pending=null;expires=0;throw e;});}
 return pending;
}
function reply(body,type,head,{status=200,cache=true}={}) {
 return new Response(head?null:body,{status,headers:{"content-type":type+"; charset=utf-8","cache-control":cache?"public, max-age=300, s-maxage=3600":"no-store","x-content-type-options":"nosniff","referrer-policy":"strict-origin-when-cross-origin"}});
}
function addCatalogueLink(response) {
 if(response.status!==200||!globalThis.HTMLRewriter)return response;
 const h=new Headers(response.headers);h.delete("etag");h.delete("content-length");
 return new HTMLRewriter().on("h1",{element(e){e.after('<p><a href="/library/catalogue/">Browse every article and research page without JavaScript</a></p>',{html:true});}}).transform(new Response(response.body,{status:response.status,headers:h}));
}
async function publicDiscoveryResponse(request,env,ctx) {
 const url=new URL(request.url),p=url.pathname,head=request.method==="HEAD";
 const handled=p==="/llms.txt"||p==="/ai-discovery.json"||p==="/library/catalogue"||p.startsWith("/library/catalogue/");
 if(!handled)return null;
 if(request.method!=="GET"&&!head)return new Response("Method not allowed",{status:405,headers:{allow:"GET, HEAD"}});
 if(p==="/llms.txt")return reply(discoveryMarkdown(),"text/plain",head);
 if(p==="/ai-discovery.json")return reply(encodeJson(DISCOVERY_PROFILE),"application/json",head);
 if(p==="/library/catalogue")return Response.redirect(ORIGIN+"/library/catalogue/",301);
 const m=p.match(/^\/library\/catalogue\/(?:([1-9]\d*)\/)?$/),sitemap=p==="/library/catalogue/sitemap.xml";
 if(!m&&!sitemap)return reply("Not found","text/plain",head,{status:404,cache:false});
 let rows;try{rows=await loadCatalogue(env);}catch{return reply("Catalogue temporarily unavailable; use /library.","text/plain",head,{status:503,cache:false});}
 if(!rows.length)return reply("Catalogue temporarily unavailable; use /library.","text/plain",head,{status:503,cache:false});
 const pages=Math.ceil(rows.length/SIZE),n=m?Number(m[1]||1):1;
 const route=i=>i===1?"/library/catalogue/":"/library/catalogue/"+i+"/";
 if(sitemap){const xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+Array.from({length:pages},(_,i)=>"<url><loc>"+ORIGIN+route(i+1)+"</loc></url>").join("")+"</urlset>";return reply(xml,"application/xml",head);}
 if(!Number.isSafeInteger(n)||n>pages)return reply("Not found","text/plain",head,{status:404,cache:false});
 if(m[1]==="1")return Response.redirect(ORIGIN+route(1),301);
 const batch=rows.slice((n-1)*SIZE,n*SIZE),canonical=ORIGIN+route(n);
 const nav=Array.from({length:pages},(_,i)=>'<a href="'+route(i+1)+'"'+(n===i+1?' aria-current="page"':"")+">"+(i+1)+"</a>").join(" ");
 const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AafnaiPatro article catalogue — page '+n+' of '+pages+'</title><meta name="description" content="Browse source-backed AafnaiPatro articles and linked research pages with direct links, without JavaScript."><link rel="canonical" href="'+canonical+'"><meta name="robots" content="index,follow"><script type="application/ld+json">'+encodeJson({"@context":"https://schema.org","@type":"CollectionPage",url:canonical,name:"AafnaiPatro article catalogue — page "+n,mainEntity:{"@type":"ItemList",numberOfItems:batch.length,itemListElement:batch.map((a,i)=>({"@type":"ListItem",position:(n-1)*SIZE+i+1,url:ORIGIN+a.path,name:a.title}))}})+'</script></head><body><main><a href="/library">Search the library</a> · <a href="/advancetools/">Browser tools</a> · <a href="/">AafnaiPatro</a><h1>Article and research catalogue</h1><p>'+rows.length.toLocaleString("en-US")+' articles · page '+n+' of '+pages+'. Source-backed explanations; publication does not imply independent peer review.</p><nav aria-label="Catalogue pages">'+nav+'</nav><ol start="'+((n-1)*SIZE+1)+'">'+batch.map(a=>'<li><article><h2><a href="'+a.path+'">'+esc(a.title)+'</a></h2><p>'+esc(a.dek)+'</p><p>'+esc(a.sector)+(a.research?' · <a href="'+a.research+'">Sources and research</a>':"")+'</p></article></li>').join("")+'</ol><nav aria-label="More catalogue pages">'+nav+'</nav><p><a href="/sources">Editorial sources</a> · <a href="/privacy">Privacy</a> · <a href="/contact">Contact</a></p></main></body></html>';
 return reply(html,"text/html",head);
}


const __PATRO_GA_ID="G-KWLDWTSK14";
const __PATRO_GA_HASH="'sha256-tcnd4K/edH7A3LzDRjFjIfm3GTH8JtfJOBjNzuzjydg='";
const __PATRO_GA_HTML='<!-- Google tag (gtag.js) -->\n<script data-patro-google-tag async src="https://www.googletagmanager.com/gtag/js?id=G-KWLDWTSK14"></script>\n<script data-patro-google-tag>\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag(\'js\', new Date());\n\n  gtag(\'config\', \'G-KWLDWTSK14\');\n</script>';
const __PatroNativeResponse=Response;
function __patroCsp(policy){
 if(!policy)return policy;
 const directives=new Map(policy.split(";").map(p=>p.trim().split(/\s+/)).filter(([n])=>n).map(([n,...v])=>[n.toLowerCase(),v]));
 const allow=(name,sources,fallback="default-src")=>{const values=[...(directives.get(name)||directives.get(fallback)||[])].filter(v=>v!=="'none'");directives.set(name,[...new Set([...values,...sources])]);};
 for(const name of ["script-src",...(directives.has("script-src-elem")?["script-src-elem"]:[])]){
   const values=directives.get(name)||directives.get("script-src")||directives.get("default-src")||[];
   const needsHash=!values.includes("'unsafe-inline'")||values.some(v=>/^'(sha\d+-|nonce-)/.test(v));
   allow(name,["https://www.googletagmanager.com",...(needsHash?[__PATRO_GA_HASH]:[])],name==="script-src"?"default-src":"script-src");
 }
 allow("connect-src",["'self'","https://www.googletagmanager.com","https://*.google-analytics.com","https://*.analytics.google.com"]);
 allow("img-src",["https://*.google-analytics.com","https://www.googletagmanager.com"]);
 return [...directives].map(([n,v])=>n+" "+v.join(" ")).join("; ");
}
function __patroDecorate(response){
 if(!response||!(response.headers.get("content-type")||"").toLowerCase().includes("text/html")||!globalThis.HTMLRewriter)return response;
 const headers=new Headers(response.headers),csp=headers.get("content-security-policy");if(csp)headers.set("content-security-policy",__patroCsp(csp));headers.delete("content-length");headers.delete("etag");
 const clean=new __PatroNativeResponse(response.body,{status:response.status,statusText:response.statusText,headers});
 return new HTMLRewriter().on("head",{element(el){el.prepend(__PATRO_GA_HTML,{html:true});}}).on("script[data-patro-google-tag]",{element(el){el.remove();}}).on("meta[http-equiv]",{element(el){if((el.getAttribute("http-equiv")||"").toLowerCase()==="content-security-policy"){const p=el.getAttribute("content")||"";el.setAttribute("content",__patroCsp(p));}}}).transform(clean);
}
function __patroResponse(body,init){return __patroDecorate(new __PatroNativeResponse(body,init));}

var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// worker.mjs
var HTML_HEADERS = {
  "content-type": "text/html; charset=utf-8",
  "x-content-type-options": "nosniff",
  "referrer-policy": "strict-origin-when-cross-origin",
  "permissions-policy": "camera=(), microphone=(), geolocation=()"
};
function clean(path) {
  return path.replace(/\/+$/, "") || "/";
}
__name(clean, "clean");
function safeSlug(value) {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value);
}
__name(safeSlug, "safeSlug");
function typeFor(key) {
  if (key.endsWith(".json")) return "application/json; charset=utf-8";
  if (key.endsWith(".xml")) return "application/xml; charset=utf-8";
  if (key.endsWith(".svg")) return "image/svg+xml";
  if (key.endsWith(".js")) return "text/javascript; charset=utf-8";
  if (key.endsWith(".css")) return "text/css; charset=utf-8";
  if (key.endsWith(".html")) return "text/html; charset=utf-8";
  return "application/octet-stream";
}
__name(typeFor, "typeFor");
async function r2(env, key, request, ctx, { immutable = false, html = false } = {}) {
  const cache = caches.default;
  const cacheKey = new Request(request.url, { method: "GET" });
  if (request.method === "GET") {
    const hit = await cache.match(cacheKey);
    if (hit) return __patroDecorate(hit);
  }
  const object = await env.LIBRARY.get(key);
  if (!object) return __patroResponse("Not found", { status: 404, headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "public, max-age=60" } });
  const headers = new Headers(object.httpMetadata || {});
  headers.set("content-type", html ? "text/html; charset=utf-8" : headers.get("content-type") || typeFor(key));
  headers.set("cache-control", immutable ? "public, max-age=31536000, immutable" : "public, max-age=300, s-maxage=86400, stale-while-revalidate=604800");
  headers.set("etag", object.httpEtag);
  if (html) for (const [k, v] of Object.entries(HTML_HEADERS)) headers.set(k, v);
  const response = __patroResponse(request.method === "HEAD" ? null : object.body, { headers });
  if (request.method === "GET") ctx.waitUntil(cache.put(cacheKey, response.clone()).catch(() => {
  }));
  return response;
}
__name(r2, "r2");
var worker_default = {
  async fetch(request, env, ctx) {
    if (request.method !== "GET" && request.method !== "HEAD") return __patroResponse("Method not allowed", { status: 405, headers: { allow: "GET, HEAD" } });
    const discovery = await publicDiscoveryResponse(request, env, ctx);
    if (discovery) return __patroDecorate(discovery);
    const url = new URL(request.url), path = clean(url.pathname);
    if (path === "/library" || path === "/library/") return addCatalogueLink(await r2(env, "phase1/library.html", request, ctx, { html: true }));
    if (path === "/library-index.json") return await r2(env, "phase1/catalog.json", request, ctx);
    if (path === "/sitemap-library.xml") return await r2(env, "phase1/sitemap.xml", request, ctx);
    let m = path.match(/^\/article\/([a-z0-9-]+)$/);
    if (m && safeSlug(m[1])) return await r2(env, "phase1/article/" + m[1] + ".html", request, ctx, { html: true });
    m = path.match(/^\/research\/([a-z0-9-]+)$/);
    if (m && safeSlug(m[1])) return await r2(env, "phase1/research/" + m[1] + ".html", request, ctx, { html: true });
    m = path.match(/^\/blogs\/([a-z0-9-]+)$/);
    if (m && safeSlug(m[1])) {
      url.pathname = "/article/" + m[1];
      return Response.redirect(url.toString(), 301);
    }
    m = path.match(/^\/library-media\/(.+)$/);
    if (m) {
      const key = m[1];
      if (key.includes("..") || key.startsWith("/")) return __patroResponse("Bad path", { status: 400 });
      return await r2(env, "phase1/" + key, request, ctx, { immutable: true });
    }
    return __patroResponse("Aafnai Library route not found", { status: 404, headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" } });
  }
};
export {
  worker_default as default
};
//# sourceMappingURL=worker.js.map
