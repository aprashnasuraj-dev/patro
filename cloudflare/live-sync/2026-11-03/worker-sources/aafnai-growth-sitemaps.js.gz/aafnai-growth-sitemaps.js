/* AafnaiPatro centralized cross-site deployed-product sitemap. Public canonical host only. Do not edit legacy DNS/routes. */
'use strict';
const HOST='sitemaps.aafnaipatro.com';
const URLS=["https://aafnaipatro.com/","https://bali-tools.aafnaipatro.com/","https://global-tools.aafnaipatro.com/","https://renovation-quotes.aafnaipatro.com/","https://uposatha.aafnaipatro.com/","https://school-transfer.aafnaipatro.com/","https://heat-rules.aafnaipatro.com/"];
const XML='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+URLS.map(u=>'  <url><loc>'+u+'</loc></url>').join('\n')+'\n</urlset>\n';
const ROBOTS='User-agent: *\nAllow: /sitemap.xml\nSitemap: https://sitemaps.aafnaipatro.com/sitemap.xml\n';
const common={'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'public,max-age=3600'};
addEventListener('fetch',event=>event.respondWith(handle(event.request)));
async function handle(request){
 const u=new URL(request.url),m=request.method.toUpperCase();
 if(m!=='GET'&&m!=='HEAD')return new Response('Method not allowed',{status:405,headers:{...common,Allow:'GET, HEAD'}});
 if(u.pathname==='/'||u.pathname==='/sitemap-index.xml')return Response.redirect('https://'+HOST+'/sitemap.xml',308);
 if(u.pathname==='/sitemap.xml')return new Response(m==='HEAD'?null:XML,{status:200,headers:{...common,'Content-Type':'application/xml; charset=utf-8'}});
 if(u.pathname==='/robots.txt')return new Response(m==='HEAD'?null:ROBOTS,{status:200,headers:{...common,'Content-Type':'text/plain; charset=utf-8'}});
 return new Response('Not found',{status:404,headers:{...common,'Content-Type':'text/plain; charset=utf-8','X-Robots-Tag':'noindex, nofollow'}});
}
