// HA-145: additive, live-preserving tools sitemap overlay. Does not modify apex Worker or assets.
export const TOOLS_SITEMAP_PATH = '/sitemap-tools.xml';
export const VERIFIED_TOOL_URLS = Object.freeze([
  "https://aafnaipatro.com/advanced-tools/puzzle-hunt-planner/",
  "https://aafnaipatro.com/advanced-tools/weaving-warp-planner/",
  "https://aafnaipatro.com/advanced-tools/weaving-warp-planner/heddle-count-planner/",
  "https://aafnaipatro.com/advanced-tools/weaving-warp-planner/warp-yarn-estimator/",
  "https://aafnaipatro.com/advanced-tools/weaving-warp-planner/wif-threading-check/",
  "https://aafnaipatro.com/advanced-tools/tournament-rescheduler/",
  "https://aafnaipatro.com/advanced-tools/tournament-rescheduler/reschedule/",
  "https://aafnaipatro.com/advanced-tools/tournament-rescheduler/court-board/",
  "https://aafnaipatro.com/advanced-tools/tournament-rescheduler/fixture-check/",
  "https://aafnaipatro.com/advanced-tools/knitting-gauge-repeat-planner/",
  "https://aafnaipatro.com/advanced-tools/knitting-gauge-repeat-planner/gauge-scenarios/",
  "https://aafnaipatro.com/advanced-tools/knitting-gauge-repeat-planner/repeat-fit/",
  "https://aafnaipatro.com/advanced-tools/knitting-gauge-repeat-planner/row-map/",
  "https://aafnaipatro.com/advanced-tools/fabric-nesting-planner/",
  "https://aafnaipatro.com/advanced-tools/fabric-nesting-planner/roll-layout/",
  "https://aafnaipatro.com/advanced-tools/fabric-nesting-planner/remnant-fit/",
  "https://aafnaipatro.com/advanced-tools/fabric-nesting-planner/marking-check/",
  "https://aafnaipatro.com/advanced-tools/audio-loop-batch-editor/",
  "https://aafnaipatro.com/advanced-tools/audio-loop-batch-editor/loop-batch/",
  "https://aafnaipatro.com/advanced-tools/audio-loop-batch-editor/seam-audition/",
  "https://aafnaipatro.com/advanced-tools/audio-loop-batch-editor/sampler-pack/",
  "https://aafnaipatro.com/advanced-tools/bead-pattern-inventory-planner/",
  "https://aafnaipatro.com/advanced-tools/bead-pattern-inventory-planner/inventory-fit/",
  "https://aafnaipatro.com/advanced-tools/bead-pattern-inventory-planner/pattern-edit/",
  "https://aafnaipatro.com/advanced-tools/bead-pattern-inventory-planner/materials-proof/",
  "https://aafnaipatro.com/advanced-tools/board-game-card-generator/",
  "https://aafnaipatro.com/advanced-tools/board-game-card-generator/deck-build/",
  "https://aafnaipatro.com/advanced-tools/board-game-card-generator/duplex-proof/",
  "https://aafnaipatro.com/advanced-tools/board-game-card-generator/revision-pack/",
  "https://aafnaipatro.com/advanced-tools/chordpro-setlist-builder/",
  "https://aafnaipatro.com/advanced-tools/chordpro-setlist-builder/setlist-pack/",
  "https://aafnaipatro.com/advanced-tools/chordpro-setlist-builder/part-transpose/",
  "https://aafnaipatro.com/advanced-tools/chordpro-setlist-builder/revision-summary/",
  "https://aafnaipatro.com/advanced-tools/font-subsetter-language-checker/",
  "https://aafnaipatro.com/advanced-tools/font-subsetter-language-checker/coverage/",
  "https://aafnaipatro.com/advanced-tools/font-subsetter-language-checker/subset-pack/",
  "https://aafnaipatro.com/advanced-tools/font-subsetter-language-checker/shape-proof/",
  "https://aafnaipatro.com/advanced-tools/epub-edition-comparison/",
  "https://aafnaipatro.com/advanced-tools/epub-edition-comparison/edition-compare/",
  "https://aafnaipatro.com/advanced-tools/epub-edition-comparison/chapter-map/",
  "https://aafnaipatro.com/advanced-tools/epub-edition-comparison/release-check/",
  "https://aafnaipatro.com/advanced-tools/quiz-bank-converter/",
  "https://aafnaipatro.com/advanced-tools/quiz-bank-converter/qti-to-moodle/",
  "https://aafnaipatro.com/advanced-tools/quiz-bank-converter/moodle-to-qti/",
  "https://aafnaipatro.com/advanced-tools/quiz-bank-converter/quiz-bank-loss-report/",
  "https://aafnaipatro.com/advanced-tools/survey-branching-tester/",
  "https://aafnaipatro.com/advanced-tools/survey-branching-tester/unreachable-question-check/",
  "https://aafnaipatro.com/advanced-tools/survey-branching-tester/xlsform-relevance-test/",
  "https://aafnaipatro.com/advanced-tools/survey-branching-tester/survey-required-conflicts/",
  "https://aafnaipatro.com/advanced-tools/story-continuity-checker/",
  "https://aafnaipatro.com/advanced-tools/story-continuity-checker/timeline-contradiction-check/",
  "https://aafnaipatro.com/advanced-tools/story-continuity-checker/character-age-check/",
  "https://aafnaipatro.com/advanced-tools/story-continuity-checker/relative-event-shift/",
  "https://aafnaipatro.com/advanced-tools/theatre-rehearsal-scheduler/",
  "https://aafnaipatro.com/advanced-tools/theatre-rehearsal-scheduler/cast-availability-scheduler/",
  "https://aafnaipatro.com/advanced-tools/theatre-rehearsal-scheduler/scene-room-conflict-check/",
  "https://aafnaipatro.com/advanced-tools/theatre-rehearsal-scheduler/rehearsal-call-sheet/",
  "https://aafnaipatro.com/advanced-tools/qmk-keymap-simulator/",
  "https://aafnaipatro.com/advanced-tools/qmk-keymap-simulator/tap-hold-boundary-test/",
  "https://aafnaipatro.com/advanced-tools/qmk-keymap-simulator/qmk-layer-simulator/",
  "https://aafnaipatro.com/advanced-tools/qmk-keymap-simulator/qmk-combo-trace/",
  "https://aafnaipatro.com/advanced-tools/pgn-repertoire-diff/",
  "https://aafnaipatro.com/advanced-tools/pgn-repertoire-diff/pgn-transposition-diff/",
  "https://aafnaipatro.com/advanced-tools/pgn-repertoire-diff/repertoire-comment-conflicts/",
  "https://aafnaipatro.com/advanced-tools/pgn-repertoire-diff/pgn-position-compare/",
  "https://aafnaipatro.com/advanced-tools/animation-exposure-sheet/",
  "https://aafnaipatro.com/advanced-tools/animation-exposure-sheet/frame-time-converter/",
  "https://aafnaipatro.com/advanced-tools/animation-exposure-sheet/fps-retime-check/",
  "https://aafnaipatro.com/advanced-tools/animation-exposure-sheet/exposure-sheet-csv/",
  "https://aafnaipatro.com/advanced-tools/qualitative-coding-comparison/",
  "https://aafnaipatro.com/advanced-tools/qualitative-coding-comparison/coder-disagreement-review/",
  "https://aafnaipatro.com/advanced-tools/qualitative-coding-comparison/missing-unit-audit/",
  "https://aafnaipatro.com/advanced-tools/qualitative-coding-comparison/adjudication-export/",
  "https://captions.aafnaipatro.com/",
  "https://captions.aafnaipatro.com/timing/",
  "https://captions.aafnaipatro.com/inspect-convert/",
  "https://aafnaipatro.com/advanced-tools/icu-message-validator/",
  "https://aafnaipatro.com/advanced-tools/icu-message-validator/icu-check/",
  "https://aafnaipatro.com/advanced-tools/icu-message-validator/locale-matrix/",
  "https://aafnaipatro.com/advanced-tools/icu-message-validator/pseudo-locale/"
]);
const MAX_UPSTREAM_XML_BYTES = 2_000_000;
const SITEMAP_NS = 'http://www.sitemaps.org/schemas/sitemap/0.9';

export function freshToolSitemap(urls = VERIFIED_TOOL_URLS) {
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="${SITEMAP_NS}">\n${urls.map(url => `  <url><loc>${url}</loc></url>`).join('\n')}\n</urlset>\n`;
}

export function mergeToolSitemap(xml, urls = VERIFIED_TOOL_URLS) {
  if (typeof xml !== 'string' || xml.length > MAX_UPSTREAM_XML_BYTES ||
      /<!DOCTYPE|<!ENTITY|<!\[CDATA\[|<script\b/i.test(xml) ||
      !/<urlset(?:\s[^>]*)?>/i.test(xml) || !/<\/urlset\s*>\s*$/i.test(xml) ||
      /<sitemapindex\b/i.test(xml)) return null;
  const existing = new Set([...xml.matchAll(/<loc>\s*([^<]+?)\s*<\/loc>/gi)].map(m => m[1].trim().replace(/&amp;/g, '&')));
  const additions = [...new Set(urls)].filter(url => !existing.has(url));
  if (!additions.length) return xml;
  return xml.replace(/<\/urlset\s*>\s*$/i,
    additions.map(url => `  <url><loc>${url}</loc></url>`).join('\n') + '\n</urlset>\n');
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== TOOLS_SITEMAP_PATH) return new Response('Not found', {status: 404});
    if (request.method !== 'GET' && request.method !== 'HEAD')
      return new Response('Method not allowed', {status: 405, headers: {'Allow': 'GET, HEAD'}});
    if (!env.APEX || typeof env.APEX.fetch !== 'function')
      return new Response('Upstream unavailable', {status: 503});
    let upstream;
    try {
      // A Worker service binding calls the original apex Worker directly, bypassing this route.
      upstream = await env.APEX.fetch(new Request(request.url, {method: 'GET', headers: {'Accept': 'application/xml'}}));
    } catch (_) { return new Response('Upstream unavailable', {status: 503}); }
    let xml, source;
    if (upstream.status === 404 || upstream.status === 410) {
      xml = freshToolSitemap(); source = 'new-urlset';
    } else if (upstream.status === 200) {
      const upstreamXml = await upstream.text();
      xml = mergeToolSitemap(upstreamXml);
      // Never replace an existing sitemap/index/asset with a stale or unparseable snapshot.
      if (xml === null) return new Response(request.method === 'HEAD' ? null : upstreamXml,
        {status: 200, headers: upstream.headers});
      source = 'apex-preserved-merged';
    } else {
      return new Response('Upstream sitemap unavailable', {status: 503});
    }
    return new Response(request.method === 'HEAD' ? null : xml, {status: 200, headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, max-age=300, s-maxage=300',
      'X-Content-Type-Options': 'nosniff',
      'X-Aafnai-Sitemap-Source': source
    }});
  }
};
