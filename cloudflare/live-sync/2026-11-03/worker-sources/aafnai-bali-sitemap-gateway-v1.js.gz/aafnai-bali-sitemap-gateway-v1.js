const SITEMAP = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>https://bali-tools.aafnaipatro.com/</loc></url>\n</urlset>`;
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/sitemap.xml") {
      return new Response(SITEMAP, {
        status: 200,
        headers: {
          "content-type": "application/xml; charset=UTF-8",
          "cache-control": "public, max-age=3600",
          "x-content-type-options": "nosniff"
        }
      });
    }
    return env.BALI.fetch(request);
  }
};