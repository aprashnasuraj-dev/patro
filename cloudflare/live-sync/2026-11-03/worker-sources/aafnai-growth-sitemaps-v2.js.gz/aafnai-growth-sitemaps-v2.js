'use strict';
const XML="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n  <url><loc>https://aafnaipatro.com/</loc></url>\n  <url><loc>https://bali-tools.aafnaipatro.com/</loc></url>\n  <url><loc>https://global-tools.aafnaipatro.com/</loc></url>\n  <url><loc>https://renovation-quotes.aafnaipatro.com/</loc></url>\n  <url><loc>https://uposatha.aafnaipatro.com/</loc></url>\n  <url><loc>https://school-transfer.aafnaipatro.com/</loc></url>\n  <url><loc>https://heat-rules.aafnaipatro.com/</loc></url>\n  <url><loc>https://incident-studio.aafnaipatro.com/</loc></url>\n  <url><loc>https://math-practice.aafnaipatro.com/</loc></url>\n  <url><loc>https://aafnaipatro.com/advanced-tools/puzzle-hunt-planner/</loc></url>\n</urlset>\n";
addEventListener('fetch',event=>event.respondWith((async()=>{
  const u=new URL(event.request.url);
  if(event.request.method!=='GET'&&event.request.method!=='HEAD')return new Response('Read only',{status:405,headers:{Allow:'GET, HEAD'}});
  if(u.pathname==='/'||u.pathname==='/sitemap.xml')return new Response(event.request.method==='HEAD'?null:XML,{headers:{'Content-Type':'application/xml; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'}});
  return new Response('Not found',{status:404});
})()));