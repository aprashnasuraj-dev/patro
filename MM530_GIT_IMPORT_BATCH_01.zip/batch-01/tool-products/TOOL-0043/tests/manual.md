# TOOL-0043 deferred integration / acceptance checks

- [ ] Browser: desktop and 320px viewport; all controls labelled, keyboard only, focus visible.
- [ ] Source values with HTML/JS markup display as plain text; no DOM injection.
- [ ] Copy and download produce the exact text shown, filename safe, URL revoked.
- [ ] Empty, very long, malformed, duplicate, unsafe and pathological inputs rejected or warned explicitly.
- [ ] No requests for ordinary local calculations; only explicit remote test connection on protocol routes.
- [ ] Validate against authoritative sources: https://www.rfc-editor.org/rfc/rfc10025.html and https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie.
- [ ] QA status remains TEST_PENDING until actual execution.
