import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { testTimeout: 60_000 }, resolve: { alias: { '@/patro-tools': new URL('./src/patro-tools', import.meta.url).pathname, '@/server': new URL('./src/server', import.meta.url).pathname } } });
