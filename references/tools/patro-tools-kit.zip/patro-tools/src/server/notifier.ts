/** TEMPLATE — send via FCM push, email (Resend/SES) and/or Viber. */
import type { Notifier } from '@/patro-tools/letters/letters';
export const notifier: Notifier = {
  async letterArrived(letter, url) {
    console.log(`[notify] ${letter.recipient.name}: ${letter.authorName}ले लेखेको चिठी खुल्यो → ${url}`);
  },
};
