/**
 * TEMPLATE — wrap YOUR verified BS↔AD converter here.
 *   import { adToBs, bsToAd } from '@/lib/your-bs-converter';
 */
import type { BsAdapter } from '@/patro-tools/core/types';

export const bsAdapter: BsAdapter = {
  toAD() { throw new Error('connect your BS→AD converter in src/server/bs-adapter.ts'); },
  toBS() { throw new Error('connect your AD→BS converter in src/server/bs-adapter.ts'); },
};
