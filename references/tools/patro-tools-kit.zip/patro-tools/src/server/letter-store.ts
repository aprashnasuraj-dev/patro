/** TEMPLATE — replace the in-memory map with your database (Supabase/Postgres/Firestore). */
import type { FutureLetter, LetterStore } from '@/patro-tools/letters/letters';

const mem = new Map<string, FutureLetter>();
export const letterStore: LetterStore = {
  async create(l) { mem.set(l.id, l); },
  async get(id) { return mem.get(id) ?? null; },
  async due(now, limit) { return [...mem.values()].filter((l) => !l.deliveredAt && Date.parse(l.openAt) <= now.getTime()).slice(0, limit); },
  async markDelivered(id, at) { const l = mem.get(id); if (l) l.deliveredAt = at.toISOString(); },
  async markOpened(id, at) { const l = mem.get(id); if (l) l.openedAt = at.toISOString(); },
  async listByAuthor(a) { return [...mem.values()].filter((l) => l.authorId === a); },
};
/*
 Postgres schema:
 create table future_letters (
   id uuid primary key, author_id text not null, author_name text not null,
   recipient jsonb not null, open_at timestamptz not null, open_at_label text,
   sealed jsonb not null, teaser text, created_at timestamptz default now(),
   delivered_at timestamptz, opened_at timestamptz, editable_until timestamptz
 );
 create index on future_letters (open_at) where delivered_at is null;
*/
