/** TEMPLATE — wire to your existing Google login session. */
export async function requireUser(_req: Request): Promise<{ id: string; name: string }> {
  throw new Error('requireUser not implemented: connect to your Google sign-in session');
}
