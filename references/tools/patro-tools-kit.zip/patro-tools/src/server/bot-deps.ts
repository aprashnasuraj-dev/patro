/** TEMPLATE — plug in your real BS converter, rashifal source and subscriber table. */
import type { BotDeps } from '@/patro-tools/bots/responder';
import type { SubscriberStore } from '@/patro-tools/bots/channels';
import { bsAdapter } from './bs-adapter';

export const botDeps: BotDeps = {
  bs: bsAdapter,
  appUrl: process.env.PUBLIC_BASE_URL ?? 'https://patro-blush.vercel.app',
  // rashifal: (rashi, date) => getRashifal(rashi, date),
  // officialFestivals: await loadOfficialFestivalTable(),
};

const mem = { viber: new Set<string>(), telegram: new Set<string>() };
export const subscribers: SubscriberStore = {
  async set(ch, id, on) { on ? mem[ch].add(id) : mem[ch].delete(id); },
  async list(ch) { return [...mem[ch]]; },
};
