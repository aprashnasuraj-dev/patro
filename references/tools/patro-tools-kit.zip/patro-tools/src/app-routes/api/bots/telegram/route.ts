import { telegram } from '@/patro-tools/bots/channels';
import { parseIntent } from '@/patro-tools/bots/intents';
import { reply } from '@/patro-tools/bots/responder';
import { botDeps, subscribers } from '@/server/bot-deps';

export async function POST(req: Request) {
  if (!telegram.verify(req.headers.get('x-telegram-bot-api-secret-token'), process.env.TELEGRAM_WEBHOOK_SECRET!)) return new Response('forbidden', { status: 403 });
  const update = await req.json();
  const msg = update.message;
  if (!msg?.text) return new Response('ok');
  const text = msg.text === '/start' ? 'help' : msg.text;
  const intent = parseIntent(text);
  if (intent.type === 'subscribe' || intent.type === 'unsubscribe') await subscribers.set('telegram', String(msg.chat.id), intent.type === 'subscribe');
  await telegram.send(process.env.TELEGRAM_TOKEN!, msg.chat.id, await reply(intent, botDeps));
  return new Response('ok');
}
