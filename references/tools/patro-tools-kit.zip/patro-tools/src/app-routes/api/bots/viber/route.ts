import { viber } from '@/patro-tools/bots/channels';
import { parseIntent } from '@/patro-tools/bots/intents';
import { reply } from '@/patro-tools/bots/responder';
import { botDeps, subscribers } from '@/server/bot-deps'; // ← your BS adapter, rashifal, store

export async function POST(req: Request) {
  const raw = await req.text();
  const token = process.env.VIBER_TOKEN!;
  if (!(await viber.verify(raw, req.headers.get('x-viber-content-signature'), token))) return new Response('bad signature', { status: 401 });
  const ev = JSON.parse(raw);

  switch (ev.event) {
    case 'conversation_started':
      // Viber lets you reply inline to conversation_started (a welcome message)
      return Response.json({ sender: { name: 'मेरो पात्रो' }, type: 'text', text: await reply({ type: 'help' }, botDeps), keyboard: viber.keyboard(), min_api_version: 3 });
    case 'subscribed':
      await subscribers.set('viber', ev.user.id, true);
      break;
    case 'unsubscribed':
      await subscribers.set('viber', ev.user_id, false);
      break;
    case 'message': {
      const intent = parseIntent(ev.message?.text ?? '');
      if (intent.type === 'subscribe' || intent.type === 'unsubscribe') await subscribers.set('viber', ev.sender.id, intent.type === 'subscribe');
      await viber.send(token, ev.sender.id, await reply(intent, botDeps));
      break;
    }
  }
  return new Response('ok');
}
