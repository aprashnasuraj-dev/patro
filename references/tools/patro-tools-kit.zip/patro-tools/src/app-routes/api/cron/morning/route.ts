/**
 * Morning brief at 06:00 NPT = 00:15 UTC.
 * vercel.json: { "crons": [{ "path": "/api/cron/morning", "schedule": "15 0 * * *" }] }
 */
import { localDate } from '@/patro-tools/core/astro';
import { telegram, viber } from '@/patro-tools/bots/channels';
import { dayCard } from '@/patro-tools/bots/responder';
import { botDeps, subscribers } from '@/server/bot-deps';

export async function GET(req: Request) {
  if (req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) return new Response('unauthorized', { status: 401 });
  const text = `शुभ प्रभात 🙏\n${dayCard(localDate(new Date(), 'Asia/Kathmandu'), botDeps)}`;
  const [v, t] = await Promise.all([subscribers.list('viber'), subscribers.list('telegram')]);
  await viber.broadcast(process.env.VIBER_TOKEN!, v, text);
  // Telegram: ~30 msgs/sec limit — batch
  for (let i = 0; i < t.length; i += 25) {
    await Promise.all(t.slice(i, i + 25).map((id) => telegram.send(process.env.TELEGRAM_TOKEN!, id, text)));
    await new Promise((r) => setTimeout(r, 1100));
  }
  return Response.json({ viber: v.length, telegram: t.length });
}
