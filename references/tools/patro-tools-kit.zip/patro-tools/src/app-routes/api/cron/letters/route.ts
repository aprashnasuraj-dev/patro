/**
 * Hourly cron. vercel.json: { "crons": [{ "path": "/api/cron/letters", "schedule": "5 * * * *" }] }
 * Vercel sends "Authorization: Bearer $CRON_SECRET".
 */
import { deliverDueLetters } from '@/patro-tools/letters/letters';
import { letterStore } from '@/server/letter-store';
import { notifier } from '@/server/notifier';

export async function GET(req: Request) {
  if (req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) return new Response('unauthorized', { status: 401 });
  const result = await deliverDueLetters(letterStore, notifier, process.env.PUBLIC_BASE_URL!);
  return Response.json(result);
}
