/**
 * POST /api/letters — create a letter.
 * Body: { recipient, openAt, openAtLabel, sealed?: Sealed (passphrase mode), plaintext?: string (server mode), teaser? }
 * Env: LETTERS_KEY (base64 32 bytes: `openssl rand -base64 32`)
 */
import { NextResponse } from 'next/server';
import { sealWithServerKey, type Sealed } from '@/patro-tools/letters/crypto';
import type { FutureLetter } from '@/patro-tools/letters/letters';
import { letterStore } from '@/server/letter-store'; // ← your implementation
import { requireUser } from '@/server/auth';         // ← your Google-login session helper

export async function POST(req: Request) {
  const user = await requireUser(req);
  const body = await req.json();
  const openAt = new Date(body.openAt);
  if (isNaN(openAt.getTime()) || openAt.getTime() < Date.now() + 86_400_000) {
    return NextResponse.json({ error: 'openAt must be at least 1 day in the future' }, { status: 400 });
  }
  if (openAt.getTime() > Date.now() + 100 * 365.25 * 86_400_000) {
    return NextResponse.json({ error: 'max 100 years' }, { status: 400 });
  }
  const id = crypto.randomUUID();
  let sealed: Sealed;
  if (body.sealed?.mode === 'passphrase') sealed = body.sealed;
  else if (typeof body.plaintext === 'string' && body.plaintext.length <= 20_000) {
    sealed = await sealWithServerKey(body.plaintext, process.env.LETTERS_KEY!, 'k1', id);
  } else return NextResponse.json({ error: 'letter content required' }, { status: 400 });

  const letter: FutureLetter = {
    id,
    authorId: user.id,
    authorName: user.name,
    recipient: body.recipient,
    openAt: openAt.toISOString(),
    openAtLabel: String(body.openAtLabel ?? ''),
    sealed,
    teaser: body.teaser?.slice(0, 140),
    createdAt: new Date().toISOString(),
    editableUntil: new Date(Date.now() + 7 * 86_400_000).toISOString(),
  };
  await letterStore.create(letter);
  return NextResponse.json({ id, openAt: letter.openAt });
}
