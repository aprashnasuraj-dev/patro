/**
 * GET /api/letters/:id — locked envelope before openAt, contents after.
 * Server-sealed letters are decrypted here; passphrase letters are returned
 * sealed and opened in the browser with openWithPassphrase().
 */
import { NextResponse } from 'next/server';
import { openWithServerKey } from '@/patro-tools/letters/crypto';
import { lockState } from '@/patro-tools/letters/letters';
import { letterStore } from '@/server/letter-store';

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const letter = await letterStore.get(id);
  if (!letter) return NextResponse.json({ error: 'not found' }, { status: 404 });

  const envelope = { id, from: letter.authorName, to: letter.recipient.name, openAtLabel: letter.openAtLabel, teaser: letter.teaser };
  const state = lockState(letter);
  if (state.locked) return NextResponse.json({ ...envelope, locked: true, remaining: state.label }, { status: 423 });

  if (!letter.openedAt) await letterStore.markOpened(id, new Date());
  if (letter.sealed.mode === 'server') {
    const text = await openWithServerKey(letter.sealed, process.env.LETTERS_KEY!, id);
    return NextResponse.json({ ...envelope, locked: false, text });
  }
  return NextResponse.json({ ...envelope, locked: false, sealed: letter.sealed });
}
