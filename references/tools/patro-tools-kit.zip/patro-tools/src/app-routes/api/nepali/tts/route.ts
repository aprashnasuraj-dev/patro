/**
 * POST /api/nepali/tts { text, rate? } → audio/mpeg
 * Azure neural voices: ne-NP-HemkalaNeural (female), ne-NP-SagarNeural (male).
 * Env: AZURE_SPEECH_KEY, AZURE_SPEECH_REGION
 * Cache by hash(text+voice) in blob storage — daily rashifal/news get replayed a lot.
 */
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export async function POST(req: Request) {
  const { text, rate = 0.9, voice = 'ne-NP-HemkalaNeural' } = await req.json();
  if (!text || text.length > 3000) return new Response('text required (max 3000)', { status: 400 });
  const ssml = `<speak version="1.0" xml:lang="ne-NP"><voice name="${voice}"><prosody rate="${Math.round((rate - 1) * 100)}%">${esc(text)}</prosody></voice></speak>`;
  const res = await fetch(`https://${process.env.AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/v1`, {
    method: 'POST',
    headers: {
      'Ocp-Apim-Subscription-Key': process.env.AZURE_SPEECH_KEY!,
      'Content-Type': 'application/ssml+xml',
      'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3',
    },
    body: ssml,
  });
  if (!res.ok) return new Response('tts failed', { status: 502 });
  return new Response(res.body, { headers: { 'content-type': 'audio/mpeg', 'cache-control': 'public, max-age=86400' } });
}
