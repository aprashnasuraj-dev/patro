/**
 * POST /api/nepali/stt (multipart "audio", webm/opus from MediaRecorder) → { text }
 * Google Cloud Speech-to-Text v1 supports ne-NP and accepts WEBM_OPUS directly.
 * Env: GOOGLE_STT_API_KEY. Limit: ~60 s per request (use streaming for longer).
 */
export async function POST(req: Request) {
  const form = await req.formData();
  const file = form.get('audio');
  if (!(file instanceof Blob)) return Response.json({ error: 'audio required' }, { status: 400 });
  if (file.size > 5_000_000) return Response.json({ error: 'too long' }, { status: 413 });
  const content = Buffer.from(await file.arrayBuffer()).toString('base64');
  const res = await fetch(`https://speech.googleapis.com/v1/speech:recognize?key=${process.env.GOOGLE_STT_API_KEY}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      config: { encoding: 'WEBM_OPUS', sampleRateHertz: 48000, languageCode: 'ne-NP', enableAutomaticPunctuation: true },
      audio: { content },
    }),
  });
  if (!res.ok) return Response.json({ error: 'stt failed' }, { status: 502 });
  const data = await res.json();
  const text = (data.results ?? []).map((r: any) => r.alternatives?.[0]?.transcript ?? '').join(' ');
  return Response.json({ text });
}
