/**
 * POST /api/nepali/grammar  { text }  →  { corrected, edits[] }
 * Layer 3 of the spell checker: grammar, agreement (लिङ्ग/वचन/आदर), style.
 * Env: ANTHROPIC_API_KEY, ANTHROPIC_MODEL
 * Add rate limiting (e.g. Upstash) and a per-user daily quota before launch;
 * make unlimited use a premium feature.
 */
import { NextResponse } from 'next/server';

const SYSTEM = `तपाईं नेपाली भाषाको सम्पादक हुनुहुन्छ। नेपाल प्रज्ञा-प्रतिष्ठानको मानक हिज्जे प्रयोग गर्नुहोस्।
Correct spelling (ह्रस्व/दीर्घ, श/ष/स, ब/व), grammar (लिङ्ग, वचन, आदरार्थी क्रियापद), and punctuation.
Do NOT change meaning, tone, names, or numbers. Do not rewrite for style unless it is wrong.
Respond ONLY with JSON: {"corrected": string, "edits": [{"from": string, "to": string, "reason": string (short, in Nepali)}]}`;

export async function POST(req: Request) {
  const { text } = (await req.json()) as { text?: string };
  if (!text || text.length > 5000) return NextResponse.json({ error: 'text required (max 5000 chars)' }, { status: 400 });

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY!,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL,
      max_tokens: 4000,
      system: SYSTEM,
      messages: [{ role: 'user', content: text }],
    }),
  });
  if (!res.ok) return NextResponse.json({ error: 'upstream error' }, { status: 502 });
  const data = await res.json();
  const raw: string = data.content?.[0]?.text ?? '';
  try {
    const json = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
    return NextResponse.json(json);
  } catch {
    return NextResponse.json({ corrected: text, edits: [], warning: 'unparseable model output' });
  }
}
