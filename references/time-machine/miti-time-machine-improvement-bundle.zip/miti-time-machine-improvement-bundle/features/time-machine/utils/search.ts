import type { EventIndexItem, TimeMachineFilters } from '../types';
import { toLatinDigits } from './number';

export function normalizeSearch(value: string): string {
  return toLatinDigits(value)
    .normalize('NFKC')
    .toLocaleLowerCase('ne-NP')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function eventHaystack(event: EventIndexItem): string {
  return normalizeSearch([
    event.title,
    event.titleEn,
    event.summary,
    event.category,
    event.region,
    event.place,
    ...(event.tags ?? []),
    event.yearAD,
    event.yearBS,
  ].filter(Boolean).join(' '));
}

export function filterEvents(events: EventIndexItem[], filters: TimeMachineFilters): EventIndexItem[] {
  const query = normalizeSearch(filters.q);
  const tokens = query.split(' ').filter(Boolean);

  return events.filter((event) => {
    if (filters.era !== 'all' && event.era !== filters.era) return false;
    if (filters.category !== 'all' && event.category !== filters.category) return false;
    if (filters.region !== 'all' && event.region !== filters.region) return false;
    if (filters.monthBS !== 'all' && event.monthBS !== Number(filters.monthBS)) return false;
    if (filters.disputed === 'yes' && !event.disputed) return false;
    if (filters.disputed === 'no' && event.disputed) return false;
    if (!tokens.length) return true;

    const haystack = eventHaystack(event);
    return tokens.every((token) => haystack.includes(token));
  });
}

export function findNearestYearIndex(
  events: EventIndexItem[],
  year: number,
  calendar: 'AD' | 'BS',
): number {
  if (!events.length) return -1;

  let bestIndex = 0;
  let bestDistance = Number.POSITIVE_INFINITY;
  for (let i = 0; i < events.length; i += 1) {
    const candidate = calendar === 'BS' ? events[i].yearBS : events[i].yearAD;
    if (candidate == null) continue;
    const distance = Math.abs(candidate - year);
    if (distance < bestDistance) {
      bestDistance = distance;
      bestIndex = i;
      if (distance === 0) break;
    }
  }
  return bestIndex;
}
