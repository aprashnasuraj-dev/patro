const DEVANAGARI = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];
const LATIN_FROM_DEVANAGARI: Record<string, string> = {
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
};

export function toNepaliDigits(value: string | number): string {
  return String(value).replace(/\d/g, (digit) => DEVANAGARI[Number(digit)]);
}

export function toLatinDigits(value: string): string {
  return value.replace(/[०-९]/g, (digit) => LATIN_FROM_DEVANAGARI[digit] ?? digit);
}

export function parseFlexibleYear(value: string): number | null {
  const normalized = toLatinDigits(value).replace(/[^0-9-]/g, '').trim();
  if (!normalized) return null;
  const parsed = Number.parseInt(normalized, 10);
  return Number.isFinite(parsed) ? parsed : null;
}
