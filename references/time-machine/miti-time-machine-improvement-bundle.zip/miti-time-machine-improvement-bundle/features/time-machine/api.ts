import type { EventIndexResponse, HistoricalEvent } from './types';

async function parseOrThrow<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(text || `Time Machine API failed (${response.status})`);
  }
  return response.json() as Promise<T>;
}

export async function fetchEventIndex(signal?: AbortSignal): Promise<EventIndexResponse> {
  const response = await fetch('/api/time-machine/events', {
    method: 'GET',
    headers: { Accept: 'application/json' },
    cache: 'no-store',
    signal,
  });
  return parseOrThrow<EventIndexResponse>(response);
}

export async function fetchEventDetail(id: string, signal?: AbortSignal): Promise<HistoricalEvent> {
  const response = await fetch(`/api/time-machine/events/${encodeURIComponent(id)}`, {
    method: 'GET',
    headers: { Accept: 'application/json' },
    cache: 'force-cache',
    signal,
  });
  return parseOrThrow<HistoricalEvent>(response);
}
