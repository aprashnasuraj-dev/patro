'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { OVERSCAN_ROWS, VIRTUAL_ROW_ESTIMATE } from '../constants';

export function useVirtualTimeline(totalRows: number) {
  const [scrollTop, setScrollTop] = useState(0);
  const [viewportHeight, setViewportHeight] = useState(800);

  useEffect(() => {
    const update = () => setViewportHeight(window.innerHeight || 800);
    update();
    window.addEventListener('resize', update, { passive: true });
    return () => window.removeEventListener('resize', update);
  }, []);

  const range = useMemo(() => {
    const visibleStart = Math.floor(scrollTop / VIRTUAL_ROW_ESTIMATE);
    const visibleEnd = Math.ceil((scrollTop + viewportHeight) / VIRTUAL_ROW_ESTIMATE);
    const start = Math.max(0, visibleStart - OVERSCAN_ROWS);
    const end = Math.min(totalRows, visibleEnd + OVERSCAN_ROWS);
    return { start, end };
  }, [scrollTop, totalRows, viewportHeight]);

  const onScroll = useCallback((element: HTMLElement) => {
    setScrollTop(element.scrollTop);
    setViewportHeight(element.clientHeight || window.innerHeight || 800);
  }, []);

  return {
    ...range,
    totalHeight: totalRows * VIRTUAL_ROW_ESTIMATE,
    offsetTop: range.start * VIRTUAL_ROW_ESTIMATE,
    rowHeight: VIRTUAL_ROW_ESTIMATE,
    onScroll,
  };
}
