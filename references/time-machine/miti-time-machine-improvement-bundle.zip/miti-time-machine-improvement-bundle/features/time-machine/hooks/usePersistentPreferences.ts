'use client';

import { useCallback, useEffect, useState } from 'react';
import { STORAGE_KEY } from '../constants';

type Preferences = {
  soundEnabled: boolean;
  favorites: string[];
  lastEventId?: string;
  lastYearAD?: number;
};

const DEFAULTS: Preferences = {
  soundEnabled: false,
  favorites: [],
};

export function usePersistentPreferences() {
  const [preferences, setPreferences] = useState<Preferences>(DEFAULTS);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setPreferences({ ...DEFAULTS, ...JSON.parse(raw) });
    } catch {
      // Storage can be unavailable in private/locked contexts. Keep defaults.
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    } catch {
      // Ignore storage quota / permission errors.
    }
  }, [hydrated, preferences]);

  const toggleFavorite = useCallback((id: string) => {
    setPreferences((current) => ({
      ...current,
      favorites: current.favorites.includes(id)
        ? current.favorites.filter((item) => item !== id)
        : [...current.favorites, id],
    }));
  }, []);

  return { preferences, setPreferences, toggleFavorite, hydrated };
}
