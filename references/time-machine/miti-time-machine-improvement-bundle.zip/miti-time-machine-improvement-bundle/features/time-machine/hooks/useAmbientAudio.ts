'use client';

import { useEffect, useRef } from 'react';
import type { TimeMachineEra } from '../types';

const ERA_AUDIO: Record<TimeMachineEra, string> = {
  ancient: '/sounds/time-machine/ancient.mp3',
  medieval: '/sounds/time-machine/medieval.mp3',
  'early-modern': '/sounds/time-machine/early-modern.mp3',
  modern: '/sounds/time-machine/modern.mp3',
  contemporary: '/sounds/time-machine/contemporary.mp3',
};

export function useAmbientAudio(era: TimeMachineEra, enabled: boolean) {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!enabled) {
      audioRef.current?.pause();
      return;
    }

    const audio = new Audio(ERA_AUDIO[era]);
    audio.loop = true;
    audio.volume = 0.2;
    audio.preload = 'none';
    audioRef.current?.pause();
    audioRef.current = audio;

    void audio.play().catch(() => {
      // Browser autoplay policy may block playback until the next explicit click.
    });

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, [enabled, era]);
}
