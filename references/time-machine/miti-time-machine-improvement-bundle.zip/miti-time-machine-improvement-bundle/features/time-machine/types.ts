export type TimeMachineEra = 'ancient' | 'medieval' | 'early-modern' | 'modern' | 'contemporary';

export type EventSource = {
  label: string;
  url?: string;
  publisher?: string;
  year?: number;
  note?: string;
};

export type HistoricalEvent = {
  id: string;
  yearBS?: number;
  yearAD: number;
  monthBS?: number;
  dayBS?: number;
  monthAD?: number;
  dayAD?: number;
  title: string;
  titleEn?: string;
  summary: string;
  details?: string;
  era: TimeMachineEra;
  category: string;
  tags?: string[];
  region?: string;
  place?: string;
  figures?: string[];
  disputed?: boolean;
  confidence?: 'high' | 'medium' | 'low';
  importance?: 1 | 2 | 3 | 4 | 5;
  sources?: EventSource[];
};

export type EventIndexItem = Pick<
  HistoricalEvent,
  | 'id'
  | 'yearBS'
  | 'yearAD'
  | 'monthBS'
  | 'dayBS'
  | 'title'
  | 'titleEn'
  | 'summary'
  | 'era'
  | 'category'
  | 'tags'
  | 'region'
  | 'place'
  | 'disputed'
  | 'confidence'
  | 'importance'
>;

export type EventIndexResponse = {
  version: string;
  generatedAt: string;
  total: number;
  events: EventIndexItem[];
  facets: {
    eras: string[];
    categories: string[];
    regions: string[];
    monthsBS: number[];
    yearAD: { min: number; max: number } | null;
    yearBS: { min: number; max: number } | null;
  };
};

export type TimeMachineFilters = {
  q: string;
  era: string;
  category: string;
  region: string;
  monthBS: 'all' | string;
  disputed: 'all' | 'yes' | 'no';
};
