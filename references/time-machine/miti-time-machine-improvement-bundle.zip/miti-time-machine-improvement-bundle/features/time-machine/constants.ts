import type { TimeMachineEra } from './types';

export const ERA_LABELS: Record<TimeMachineEra, { ne: string; en: string }> = {
  ancient: { ne: 'प्राचीन', en: 'Ancient' },
  medieval: { ne: 'मध्यकालीन', en: 'Medieval' },
  'early-modern': { ne: 'पूर्व-आधुनिक', en: 'Early Modern' },
  modern: { ne: 'आधुनिक', en: 'Modern' },
  contemporary: { ne: 'समसामयिक', en: 'Contemporary' },
};

export const DEFAULT_FILTERS = {
  q: '',
  era: 'all',
  category: 'all',
  region: 'all',
  monthBS: 'all',
  disputed: 'all' as const,
};

export const VIRTUAL_ROW_ESTIMATE = 228;
export const OVERSCAN_ROWS = 7;
export const STORAGE_KEY = 'miti.time-machine.preferences.v2';
