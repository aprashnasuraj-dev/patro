'use client';

import type { EventIndexItem } from '../types';
import { ERA_LABELS } from '../constants';
import { toNepaliDigits } from '../utils/number';

type Props = {
  event: EventIndexItem;
  favorite: boolean;
  onOpen: (id: string) => void;
  onToggleFavorite: (id: string) => void;
};

export default function EventCard({ event, favorite, onOpen, onToggleFavorite }: Props) {
  return (
    <article
      className={`tm-event-card${event.disputed ? ' tm-event-card--disputed' : ''}`}
      data-event-id={event.id}
    >
      <div className="tm-event-date">
        <span>{toNepaliDigits(event.yearBS ?? '—')} वि.सं.</span>
        <span>{event.yearAD} AD</span>
      </div>
      <div className="tm-event-main">
        <div className="tm-event-kickers">
          <span>{ERA_LABELS[event.era]?.ne ?? event.era}</span>
          <span>{event.category}</span>
          {event.region ? <span>{event.region}</span> : null}
          {event.disputed ? <span title="Historical interpretation/source is disputed">विवादित</span> : null}
        </div>
        <button className="tm-event-title" onClick={() => onOpen(event.id)}>
          {event.title}
        </button>
        {event.titleEn ? <p className="tm-event-title-en">{event.titleEn}</p> : null}
        <p className="tm-event-summary">{event.summary}</p>
        {event.tags?.length ? (
          <div className="tm-tag-row">
            {event.tags.slice(0, 5).map((tag) => <span key={tag}>#{tag}</span>)}
          </div>
        ) : null}
      </div>
      <div className="tm-event-actions">
        <button
          className="tm-icon-button"
          aria-label={favorite ? 'Remove from saved events' : 'Save event'}
          aria-pressed={favorite}
          onClick={() => onToggleFavorite(event.id)}
        >
          {favorite ? '★' : '☆'}
        </button>
        <button className="tm-open-button" onClick={() => onOpen(event.id)}>खोल्नुहोस्</button>
      </div>
    </article>
  );
}
