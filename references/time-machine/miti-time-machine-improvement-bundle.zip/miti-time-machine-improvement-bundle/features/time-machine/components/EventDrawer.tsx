'use client';

import { useEffect, useState } from 'react';
import { fetchEventDetail } from '../api';
import type { HistoricalEvent } from '../types';
import { safeExternalUrl } from '../utils/source';
import { toNepaliDigits } from '../utils/number';

type Props = {
  eventId: string | null;
  favorite: boolean;
  onClose: () => void;
  onToggleFavorite: (id: string) => void;
};

export default function EventDrawer({ eventId, favorite, onClose, onToggleFavorite }: Props) {
  const [event, setEvent] = useState<HistoricalEvent | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!eventId) {
      setEvent(null);
      setError(null);
      return;
    }
    const controller = new AbortController();
    setEvent(null);
    setError(null);
    fetchEventDetail(eventId, controller.signal)
      .then(setEvent)
      .catch((reason: unknown) => {
        if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Unable to load event.');
      });
    return () => controller.abort();
  }, [eventId]);

  useEffect(() => {
    if (!eventId) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [eventId, onClose]);

  if (!eventId) return null;

  return (
    <div className="tm-drawer-backdrop" role="presentation" onMouseDown={onClose}>
      <aside
        className="tm-drawer"
        role="dialog"
        aria-modal="true"
        aria-label="Historical event details"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="tm-drawer-head">
          <button className="tm-icon-button" onClick={onClose} aria-label="Close">✕</button>
          <button
            className="tm-icon-button"
            onClick={() => onToggleFavorite(eventId)}
            aria-pressed={favorite}
            aria-label="Save event"
          >{favorite ? '★' : '☆'}</button>
        </div>
        {error ? <div className="tm-state tm-state--error">{error}</div> : null}
        {!event && !error ? <div className="tm-state">घटना लोड हुँदैछ…</div> : null}
        {event ? (
          <div className="tm-drawer-content">
            <p className="tm-drawer-date">{toNepaliDigits(event.yearBS ?? '—')} वि.सं. · {event.yearAD} AD</p>
            <h2>{event.title}</h2>
            {event.titleEn ? <h3>{event.titleEn}</h3> : null}
            <p className="tm-drawer-summary">{event.summary}</p>
            {event.details ? <p className="tm-drawer-details">{event.details}</p> : null}
            <dl className="tm-meta-grid">
              <div><dt>काल</dt><dd>{event.era}</dd></div>
              <div><dt>वर्ग</dt><dd>{event.category}</dd></div>
              {event.region ? <div><dt>क्षेत्र</dt><dd>{event.region}</dd></div> : null}
              {event.place ? <div><dt>स्थान</dt><dd>{event.place}</dd></div> : null}
              {event.confidence ? <div><dt>विश्वसनीयता</dt><dd>{event.confidence}</dd></div> : null}
              <div><dt>स्थिति</dt><dd>{event.disputed ? 'विवादित/बहु-दृष्टिकोण' : 'सामान्य अभिलेख'}</dd></div>
            </dl>
            {event.figures?.length ? (
              <section><h4>सम्बन्धित व्यक्तिहरू</h4><p>{event.figures.join(', ')}</p></section>
            ) : null}
            {event.sources?.length ? (
              <section>
                <h4>स्रोतहरू</h4>
                <ol className="tm-source-list">
                  {event.sources.map((source, index) => {
                    const href = safeExternalUrl(source.url);
                    return (
                      <li key={`${source.label}-${index}`}>
                        {href ? <a href={href} target="_blank" rel="noreferrer">{source.label}</a> : source.label}
                        {source.publisher ? <span> — {source.publisher}</span> : null}
                        {source.year ? <span> ({source.year})</span> : null}
                        {source.note ? <p>{source.note}</p> : null}
                      </li>
                    );
                  })}
                </ol>
              </section>
            ) : <p className="tm-source-empty">यस रेकर्डमा स्रोत विवरण छैन।</p>}
          </div>
        ) : null}
      </aside>
    </div>
  );
}
