'use client';

import { forwardRef, useImperativeHandle, useRef } from 'react';
import type { EventIndexItem } from '../types';
import EventCard from './EventCard';
import { useVirtualTimeline } from '../hooks/useVirtualTimeline';

export type TimelineHandle = {
  scrollToIndex: (index: number, behavior?: ScrollBehavior) => void;
};

type Props = {
  events: EventIndexItem[];
  favorites: Set<string>;
  onOpen: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onVisibleEvent?: (event: EventIndexItem | null) => void;
};

const Timeline = forwardRef<TimelineHandle, Props>(function Timeline(
  { events, favorites, onOpen, onToggleFavorite, onVisibleEvent },
  ref,
) {
  const scrollerRef = useRef<HTMLDivElement>(null);
  const virtual = useVirtualTimeline(events.length);

  useImperativeHandle(ref, () => ({
    scrollToIndex(index, behavior = 'smooth') {
      const clamped = Math.max(0, Math.min(events.length - 1, index));
      scrollerRef.current?.scrollTo({ top: clamped * virtual.rowHeight, behavior });
    },
  }), [events.length, virtual.rowHeight]);

  const visible = events.slice(virtual.start, virtual.end);

  return (
    <div
      ref={scrollerRef}
      className="tm-timeline-scroller"
      onScroll={(e) => {
        virtual.onScroll(e.currentTarget);
        const index = Math.max(0, Math.min(events.length - 1, Math.floor(e.currentTarget.scrollTop / virtual.rowHeight)));
        onVisibleEvent?.(events[index] ?? null);
      }}
    >
      <div className="tm-timeline-spacer" style={{ height: virtual.totalHeight }}>
        <div className="tm-timeline-window" style={{ transform: `translateY(${virtual.offsetTop}px)` }}>
          {visible.map((event) => (
            <div key={event.id} className="tm-virtual-row" style={{ height: virtual.rowHeight }}>
              <div className="tm-line-dot" aria-hidden="true" />
              <EventCard
                event={event}
                favorite={favorites.has(event.id)}
                onOpen={onOpen}
                onToggleFavorite={onToggleFavorite}
              />
            </div>
          ))}
        </div>
      </div>
      {!events.length ? <div className="tm-state tm-empty">कुनै मिल्दो घटना भेटिएन।</div> : null}
    </div>
  );
});

export default Timeline;
