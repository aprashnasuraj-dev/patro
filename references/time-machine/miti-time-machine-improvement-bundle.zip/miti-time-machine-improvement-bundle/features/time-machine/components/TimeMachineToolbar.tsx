'use client';

import { useState } from 'react';
import type { EventIndexResponse, TimeMachineFilters } from '../types';
import { parseFlexibleYear } from '../utils/number';

type Props = {
  filters: TimeMachineFilters;
  facets: EventIndexResponse['facets'];
  resultCount: number;
  soundEnabled: boolean;
  favoritesOnly: boolean;
  favoriteCount: number;
  onFiltersChange: (next: TimeMachineFilters) => void;
  onJump: (year: number, calendar: 'AD' | 'BS') => void;
  onToggleSound: () => void;
  onToggleFavorites: () => void;
};

export default function TimeMachineToolbar({
  filters,
  facets,
  resultCount,
  soundEnabled,
  favoritesOnly,
  favoriteCount,
  onFiltersChange,
  onJump,
  onToggleSound,
  onToggleFavorites,
}: Props) {
  const [jumpYear, setJumpYear] = useState('');
  const [calendar, setCalendar] = useState<'AD' | 'BS'>('BS');

  const update = (patch: Partial<TimeMachineFilters>) => {
    onFiltersChange({ ...filters, ...patch });
  };

  return (
    <header className="tm-toolbar">
      <div className="tm-brand">
        <div className="tm-brand-mark">◉</div>
        <div>
          <h1>मिति Time Machine</h1>
          <p>{resultCount.toLocaleString()} historical records</p>
        </div>
      </div>

      <div className="tm-search-wrap">
        <label className="tm-sr-only" htmlFor="tm-search">Search historical events</label>
        <input
          id="tm-search"
          value={filters.q}
          onChange={(e) => update({ q: e.target.value })}
          placeholder="घटना, व्यक्ति, स्थान, वर्ष खोज्नुहोस्…"
          autoComplete="off"
        />
      </div>

      <div className="tm-filter-row">
        <select aria-label="Era" value={filters.era} onChange={(e) => update({ era: e.target.value })}>
          <option value="all">सबै काल</option>
          {facets.eras.map((value) => <option key={value} value={value}>{value}</option>)}
        </select>
        <select aria-label="Category" value={filters.category} onChange={(e) => update({ category: e.target.value })}>
          <option value="all">सबै वर्ग</option>
          {facets.categories.map((value) => <option key={value} value={value}>{value}</option>)}
        </select>
        <select aria-label="Region" value={filters.region} onChange={(e) => update({ region: e.target.value })}>
          <option value="all">सबै क्षेत्र</option>
          {facets.regions.map((value) => <option key={value} value={value}>{value}</option>)}
        </select>
        {facets.monthsBS.length ? (
          <select aria-label="Bikram Sambat month" value={filters.monthBS} onChange={(e) => update({ monthBS: e.target.value })}>
            <option value="all">सबै महिना</option>
            {facets.monthsBS.map((value) => <option key={value} value={String(value)}>M{value}</option>)}
          </select>
        ) : null}
        <select
          aria-label="Disputed status"
          value={filters.disputed}
          onChange={(e) => update({ disputed: e.target.value as TimeMachineFilters['disputed'] })}
        >
          <option value="all">सबै स्थिति</option>
          <option value="no">अविवादित मात्र</option>
          <option value="yes">विवादित मात्र</option>
        </select>
      </div>

      <form
        className="tm-jump"
        onSubmit={(e) => {
          e.preventDefault();
          const parsed = parseFlexibleYear(jumpYear);
          if (parsed != null) onJump(parsed, calendar);
        }}
      >
        <input
          inputMode="numeric"
          value={jumpYear}
          onChange={(e) => setJumpYear(e.target.value)}
          placeholder="वर्ष"
          aria-label="Jump to year"
        />
        <select value={calendar} onChange={(e) => setCalendar(e.target.value as 'AD' | 'BS')} aria-label="Calendar">
          <option value="BS">वि.सं.</option>
          <option value="AD">AD</option>
        </select>
        <button type="submit">जाऊ</button>
      </form>

      <div className="tm-toolbar-actions">
        <button onClick={onToggleFavorites} aria-pressed={favoritesOnly}>★ Saved ({favoriteCount}){favoritesOnly ? ' ✓' : ''}</button>
        <button onClick={onToggleSound} aria-pressed={soundEnabled}>{soundEnabled ? '🔊 Sound' : '🔇 Sound'}</button>
      </div>
    </header>
  );
}
