'use client';

import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import { fetchEventIndex } from './api';
import { DEFAULT_FILTERS } from './constants';
import type { EventIndexItem, EventIndexResponse, TimeMachineEra, TimeMachineFilters } from './types';
import { filterEvents, findNearestYearIndex } from './utils/search';
import { usePersistentPreferences } from './hooks/usePersistentPreferences';
import { useAmbientAudio } from './hooks/useAmbientAudio';
import TimeMachineToolbar from './components/TimeMachineToolbar';
import Timeline, { type TimelineHandle } from './components/Timeline';
import EventDrawer from './components/EventDrawer';
import ParticleBackdrop from './components/ParticleBackdrop';
import './time-machine.css';

const EMPTY_FACETS: EventIndexResponse['facets'] = {
  eras: [], categories: [], regions: [], monthsBS: [], yearAD: null, yearBS: null,
};

export default function TimeMachine() {
  const [index, setIndex] = useState<EventIndexResponse | null>(null);
  const [filters, setFilters] = useState<TimeMachineFilters>(DEFAULT_FILTERS);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [visibleEvent, setVisibleEvent] = useState<EventIndexItem | null>(null);
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const restoredRef = useRef(false);
  const timelineRef = useRef<TimelineHandle>(null);
  const { preferences, setPreferences, toggleFavorite, hydrated } = usePersistentPreferences();

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    fetchEventIndex(controller.signal)
      .then((payload) => {
        setIndex(payload);
        setVisibleEvent(payload.events[0] ?? null);
      })
      .catch((reason: unknown) => {
        if (!controller.signal.aborted) setError(reason instanceof Error ? reason.message : 'Failed to load timeline.');
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, []);

  const deferredQuery = useDeferredValue(filters.q);
  const effectiveFilters = useMemo(() => ({ ...filters, q: deferredQuery }), [deferredQuery, filters]);
  const favorites = useMemo(() => new Set(preferences.favorites), [preferences.favorites]);
  const filteredEvents = useMemo(() => {
    const base = filterEvents(index?.events ?? [], effectiveFilters);
    return favoritesOnly ? base.filter((event) => favorites.has(event.id)) : base;
  }, [effectiveFilters, favorites, favoritesOnly, index?.events]);
  const era = (visibleEvent?.era ?? 'contemporary') as TimeMachineEra;
  useAmbientAudio(era, preferences.soundEnabled);

  const handleJump = useCallback((year: number, calendar: 'AD' | 'BS') => {
    const index = findNearestYearIndex(filteredEvents, year, calendar);
    if (index >= 0) timelineRef.current?.scrollToIndex(index);
  }, [filteredEvents]);

  const openEvent = useCallback((id: string) => {
    setSelectedId(id);
    const url = new URL(window.location.href);
    url.searchParams.set('event', id);
    window.history.replaceState({}, '', url);
  }, []);

  const closeEvent = useCallback(() => {
    setSelectedId(null);
    const url = new URL(window.location.href);
    url.searchParams.delete('event');
    window.history.replaceState({}, '', url);
  }, []);

  useEffect(() => {
    if (!index || !hydrated || restoredRef.current) return;
    restoredRef.current = true;
    if (!preferences.lastEventId) return;
    const restoreIndex = index.events.findIndex((event) => event.id === preferences.lastEventId);
    if (restoreIndex >= 0) {
      window.setTimeout(() => timelineRef.current?.scrollToIndex(restoreIndex, 'auto'), 0);
    }
  }, [hydrated, index, preferences.lastEventId]);

  useEffect(() => {
    if (!index || !hydrated) return;
    const eventFromUrl = new URL(window.location.href).searchParams.get('event');
    if (eventFromUrl && index.events.some((event) => event.id === eventFromUrl)) {
      setSelectedId(eventFromUrl);
    }
  }, [hydrated, index]);

  useEffect(() => {
    if (!visibleEvent || !hydrated) return;
    const timer = window.setTimeout(() => {
      setPreferences((current) => ({ ...current, lastEventId: visibleEvent.id, lastYearAD: visibleEvent.yearAD }));
    }, 350);
    return () => window.clearTimeout(timer);
  }, [hydrated, setPreferences, visibleEvent]);

  if (loading) return <main className="tm-shell"><ParticleBackdrop /><div className="tm-state tm-center">Time Machine तयार हुँदैछ…</div></main>;
  if (error) return <main className="tm-shell"><div className="tm-state tm-center tm-state--error"><strong>Timeline load failed.</strong><br />{error}</div></main>;

  return (
    <main className="tm-shell">
      <ParticleBackdrop />
      <TimeMachineToolbar
        filters={filters}
        facets={index?.facets ?? EMPTY_FACETS}
        resultCount={filteredEvents.length}
        soundEnabled={preferences.soundEnabled}
        favoritesOnly={favoritesOnly}
        favoriteCount={favorites.size}
        onFiltersChange={setFilters}
        onJump={handleJump}
        onToggleSound={() => setPreferences((current) => ({ ...current, soundEnabled: !current.soundEnabled }))}
        onToggleFavorites={() => {
          if (!favorites.size && !favoritesOnly) return;
          setFavoritesOnly((current) => !current);
          window.setTimeout(() => timelineRef.current?.scrollToIndex(0, 'auto'), 0);
        }}
      />
      <div className="tm-era-indicator" aria-live="polite">
        <span>{visibleEvent?.yearBS ? `${visibleEvent.yearBS} BS` : `${visibleEvent?.yearAD ?? ''} AD`}</span>
        <strong>{visibleEvent?.title ?? 'मिति Time Machine'}</strong>
      </div>
      <Timeline
        ref={timelineRef}
        events={filteredEvents}
        favorites={favorites}
        onOpen={openEvent}
        onToggleFavorite={toggleFavorite}
        onVisibleEvent={setVisibleEvent}
      />
      <EventDrawer
        eventId={selectedId}
        favorite={selectedId ? favorites.has(selectedId) : false}
        onClose={closeEvent}
        onToggleFavorite={toggleFavorite}
      />
    </main>
  );
}
