# Miti Time Machine Improvement Bundle

An implementation-ready replacement for the original prototype timeline.

## What changed

| Area | Prototype behaviour | Replacement |
|---|---|---|
| Data | In-memory `events.ts` samples | Repository + API adapter + JSON/DB swappable backend |
| 5,900+ events | Renders every card | Virtual timeline renders only visible rows + overscan |
| Year jump | Pixel approximation `(year - 1000) * 50` | Nearest-event lookup using actual BS/AD values |
| Search | None | Nepali/English text + Nepali/Latin digit normalization |
| Filters | None | Era, category, region, BS month (when present), disputed-state, saved-only |
| Details | Single modal | Lazy-loaded detail drawer + structured sources |
| Deep links | None | `?event=<id>` |
| Saved events | None | Browser local storage |
| Audio | Hook invoked twice in original design | One owner, native browser audio, default off |
| Particles | No resize/rAF cleanup | Resize-aware + requestAnimationFrame cleanup + reduced-motion |
| Dataset QA | None | Validator + coverage/duplicate audit + Node test |
| Coupling | UI imports static file | UI depends on stable API/repository contract |

## Design assumptions

1. Miti runs on Next.js App Router + React + TypeScript.
2. The historical dataset is already owned by the Miti project and can be exported as JSON or exposed through a server repository.
3. This bundle does **not** claim to update or verify the actual 5,900+ historical facts because that dataset was not supplied in the source document.
4. `yearAD` is required for sorting; `yearBS` is optional but strongly recommended.
5. The feature should remain usable even if optional sound assets are missing.

See `IMPLEMENTATION_GUIDE.md` for exact copy/push steps.
