#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.argv[2] || 'data/time-machine/events.json');
const events = JSON.parse(fs.readFileSync(file, 'utf8'));
if (!Array.isArray(events)) throw new Error('Dataset must be a JSON array');

const byYearTitle = new Map();
const duplicates = [];
let withSources = 0;
let withSourceUrls = 0;
let disputed = 0;
let missingBS = 0;
let exactBSDate = 0;
let exactADDate = 0;

for (const event of events) {
  const key = `${event.yearAD}|${String(event.title || '').normalize('NFKC').trim().toLocaleLowerCase('ne-NP')}`;
  if (byYearTitle.has(key)) duplicates.push([byYearTitle.get(key), event.id]);
  else byYearTitle.set(key, event.id);
  if (event.sources?.length) withSources += 1;
  if (event.sources?.some((s) => /^https?:\/\//i.test(s.url || ''))) withSourceUrls += 1;
  if (event.disputed) disputed += 1;
  if (!Number.isFinite(event.yearBS)) missingBS += 1;
  if (Number.isInteger(event.monthBS) && Number.isInteger(event.dayBS)) exactBSDate += 1;
  if (Number.isInteger(event.monthAD) && Number.isInteger(event.dayAD)) exactADDate += 1;
}

const years = events.map((e) => e.yearAD).filter(Number.isFinite);
const pct = (n) => events.length ? `${(n * 100 / events.length).toFixed(1)}%` : '0.0%';

console.log(JSON.stringify({
  file,
  total: events.length,
  yearADRange: years.length ? [Math.min(...years), Math.max(...years)] : null,
  withSources: { count: withSources, pct: pct(withSources) },
  withSourceUrls: { count: withSourceUrls, pct: pct(withSourceUrls) },
  disputed: { count: disputed, pct: pct(disputed) },
  missingBS: { count: missingBS, pct: pct(missingBS) },
  exactBSDate: { count: exactBSDate, pct: pct(exactBSDate) },
  exactADDate: { count: exactADDate, pct: pct(exactADDate) },
  possibleDuplicateYearTitlePairs: duplicates.length,
  duplicateExamples: duplicates.slice(0, 25),
}, null, 2));
