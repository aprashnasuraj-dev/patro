#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.argv[2] || 'data/time-machine/events.json');
const raw = fs.readFileSync(file, 'utf8');
const events = JSON.parse(raw);
const errors = [];
const warnings = [];
const ids = new Set();
const allowedEras = new Set(['ancient', 'medieval', 'early-modern', 'modern', 'contemporary']);

if (!Array.isArray(events)) errors.push('Root JSON value must be an array.');
else {
  events.forEach((event, index) => {
    const ref = `event[${index}]${event?.id ? `(${event.id})` : ''}`;
    if (!event?.id || typeof event.id !== 'string') errors.push(`${ref}: id is required`);
    else if (ids.has(event.id)) errors.push(`${ref}: duplicate id`);
    else ids.add(event.id);
    if (!Number.isFinite(event?.yearAD)) errors.push(`${ref}: yearAD must be a number`);
    if (event?.yearBS != null && !Number.isFinite(event.yearBS)) errors.push(`${ref}: yearBS must be a number when present`);
    if (!event?.title || typeof event.title !== 'string') errors.push(`${ref}: title is required`);
    if (!event?.summary || typeof event.summary !== 'string') errors.push(`${ref}: summary is required`);
    if (!event?.category || typeof event.category !== 'string') errors.push(`${ref}: category is required`);
    if (!allowedEras.has(event?.era)) errors.push(`${ref}: unsupported era ${JSON.stringify(event?.era)}`);
    if (!event?.sources?.length) warnings.push(`${ref}: no sources attached`);
    if (event?.sources?.some((source) => source.url && !/^https?:\/\//i.test(source.url))) {
      warnings.push(`${ref}: a source URL is not http/https and will not be linked`);
    }
  });
}

console.log(`Validated: ${file}`);
console.log(`Records: ${Array.isArray(events) ? events.length : 0}`);
if (warnings.length) {
  console.warn(`Warnings (${warnings.length}):`);
  warnings.slice(0, 100).forEach((warning) => console.warn(`  - ${warning}`));
  if (warnings.length > 100) console.warn(`  ... ${warnings.length - 100} more warnings`);
}
if (errors.length) {
  console.error(`Errors (${errors.length}):`);
  errors.slice(0, 100).forEach((error) => console.error(`  - ${error}`));
  process.exit(1);
}
console.log('OK');
