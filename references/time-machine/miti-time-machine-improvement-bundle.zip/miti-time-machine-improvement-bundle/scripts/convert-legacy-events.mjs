#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const input = process.argv[2];
const output = process.argv[3] || 'data/time-machine/events.json';
if (!input) {
  console.error('Usage: node scripts/convert-legacy-events.mjs legacy-events.json [output.json]');
  process.exit(1);
}

const legacy = JSON.parse(fs.readFileSync(path.resolve(input), 'utf8'));
if (!Array.isArray(legacy)) throw new Error('Legacy input must be a JSON array.');

function eraFromYear(yearAD) {
  if (yearAD < 1200) return 'ancient';
  if (yearAD < 1768) return 'medieval';
  if (yearAD < 1846) return 'early-modern';
  if (yearAD < 2008) return 'modern';
  return 'contemporary';
}

function idFor(item, index) {
  const stable = `${item.yearAD ?? ''}|${item.yearBS ?? ''}|${item.title ?? ''}|${index}`;
  return `evt-${crypto.createHash('sha1').update(stable).digest('hex').slice(0, 12)}`;
}

const converted = legacy.map((item, index) => ({
  id: item.id || idFor(item, index),
  yearBS: Number.isFinite(item.yearBS) ? item.yearBS : undefined,
  yearAD: Number(item.yearAD),
  title: String(item.title || 'Untitled event'),
  summary: String(item.summary || item.description || ''),
  details: item.details || undefined,
  era: item.era || eraFromYear(Number(item.yearAD)),
  category: item.category || item.tags?.[0] || 'इतिहास',
  tags: Array.isArray(item.tags) ? item.tags : [],
  region: item.region || undefined,
  place: item.place || undefined,
  disputed: Boolean(item.disputed),
  confidence: item.confidence || (item.disputed ? 'low' : 'medium'),
  importance: item.importance || 3,
  sources: Array.isArray(item.sources)
    ? item.sources.map((source) => typeof source === 'string' ? { label: source } : source)
    : [],
}));

fs.mkdirSync(path.dirname(path.resolve(output)), { recursive: true });
fs.writeFileSync(path.resolve(output), JSON.stringify(converted, null, 2) + '\n');
console.log(`Converted ${converted.length} events -> ${output}`);
