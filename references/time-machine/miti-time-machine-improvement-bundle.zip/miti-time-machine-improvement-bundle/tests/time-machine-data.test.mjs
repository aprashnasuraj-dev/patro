import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const events = JSON.parse(fs.readFileSync(new URL('../data/time-machine/events.json', import.meta.url), 'utf8'));

test('time-machine dataset is an array with unique ids', () => {
  assert.ok(Array.isArray(events));
  assert.equal(new Set(events.map((event) => event.id)).size, events.length);
});

test('all events have required index fields', () => {
  for (const event of events) {
    assert.equal(typeof event.id, 'string');
    assert.equal(typeof event.title, 'string');
    assert.equal(typeof event.summary, 'string');
    assert.ok(Number.isFinite(event.yearAD));
    assert.equal(typeof event.era, 'string');
    assert.equal(typeof event.category, 'string');
  }
});
