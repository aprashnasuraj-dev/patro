import { NextResponse } from 'next/server';
import { getEventById } from '../../../../../server/time-machine/repository';

export const runtime = 'nodejs';

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const event = await getEventById(id);
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 });

  return NextResponse.json(event, {
    headers: { 'Cache-Control': 'public, max-age=300, stale-while-revalidate=86400' },
  });
}
