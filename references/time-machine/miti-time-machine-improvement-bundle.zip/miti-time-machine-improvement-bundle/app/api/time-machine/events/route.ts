import { NextResponse } from 'next/server';
import { getEventIndex } from '../../../../server/time-machine/repository';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const payload = await getEventIndex();
    return NextResponse.json(payload, {
      headers: {
        'Cache-Control': 'private, max-age=0, must-revalidate',
        'X-Time-Machine-Events': String(payload.total),
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown Time Machine data error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
