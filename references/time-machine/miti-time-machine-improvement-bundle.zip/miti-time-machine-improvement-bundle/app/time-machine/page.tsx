import type { Metadata } from 'next';
import TimeMachine from '../../features/time-machine/TimeMachine';

export const metadata: Metadata = {
  title: 'मिति Time Machine',
  description: 'Explore Nepal and world history through a searchable interactive timeline.',
};

export default function TimeMachinePage() {
  return <TimeMachine />;
}
