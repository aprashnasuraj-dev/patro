# Miti Time Machine — Direct Implementation Guide

## Target
Drop-in replacement for the prototype Time Machine in a Next.js App Router + React + TypeScript project.
The module intentionally adds **no new npm dependency**.

## 1. Copy these folders/files into the Miti repository root

```text
app/time-machine/page.tsx
app/api/time-machine/events/route.ts
app/api/time-machine/events/[id]/route.ts
features/time-machine/**
server/time-machine/repository.ts
data/time-machine/events.json
scripts/validate-time-machine-data.mjs
scripts/convert-legacy-events.mjs
tests/time-machine-data.test.mjs
```

If your project uses `src/app`, move `app/...` under `src/app/...` and likewise place `features` + `server` under `src/` OR adjust relative imports.

## 2. Replace the sample event dataset

The bundle ships only placeholder records so that it boots immediately. Replace:

```text
data/time-machine/events.json
```

with the real Time Machine dataset. Do **not** fabricate missing historical records. Keep source metadata for each record wherever available.

Required per event:

```json
{
  "id": "stable-unique-id",
  "yearAD": 1951,
  "yearBS": 2007,
  "title": "...",
  "summary": "...",
  "era": "modern",
  "category": "राजनीति"
}
```

Supported `era` values:

```text
ancient | medieval | early-modern | modern | contemporary
```

Optional fields include exact month/day, English title, details, tags, region, place, figures, disputed flag, confidence, importance and structured sources.

## 3. Convert the legacy JSON shape if needed

If your existing 5,900+ events can be exported as JSON using the old fields (`yearBS`, `yearAD`, `title`, `description`, `tags`, `sources`, `disputed`, `region`):

```bash
node scripts/convert-legacy-events.mjs /path/to/legacy-events.json data/time-machine/events.json
node scripts/validate-time-machine-data.mjs data/time-machine/events.json
```

The converter preserves legacy data and creates stable IDs. It does not pretend to verify historical accuracy.

## 4. Add package scripts (optional but recommended)

Merge these into the root `package.json` scripts:

```json
{
  "validate:time-machine": "node scripts/validate-time-machine-data.mjs",
  "audit:time-machine": "node scripts/audit-time-machine-data.mjs",
  "test:time-machine-data": "node --test tests/time-machine-data.test.mjs"
}
```

No package installation is needed for this module.

## 5. Route integration

The bundle creates `/time-machine` for isolated testing. For your existing Miti navigation, import:

```tsx
import TimeMachine from '../features/time-machine/TimeMachine';

<TimeMachine />
```

Adjust the relative path to match the host file.

## 6. Existing database instead of JSON

`server/time-machine/repository.ts` is the only data adapter you need to replace.
Keep these two exported functions stable:

```ts
export async function getEventIndex(): Promise<EventIndexResponse>
export async function getEventById(id: string): Promise<HistoricalEvent | null>
```

This lets PostgreSQL/Prisma/Drizzle/API data replace the JSON file without changing the UI.

If you keep JSON outside the default path, set:

```bash
TIME_MACHINE_DATA_FILE=/absolute/or/project-relative/path/events.json
```

## 7. Optional ambient audio

Provide these files only if wanted:

```text
public/sounds/time-machine/ancient.mp3
public/sounds/time-machine/medieval.mp3
public/sounds/time-machine/early-modern.mp3
public/sounds/time-machine/modern.mp3
public/sounds/time-machine/contemporary.mp3
```

Sound starts disabled and is enabled only by user action.

## 8. Verification before push

```bash
node scripts/validate-time-machine-data.mjs
node scripts/audit-time-machine-data.mjs
node --test tests/time-machine-data.test.mjs
npm run build
```

Then manually verify:

- Search works for Nepali/English text and Nepali/Latin digits.
- Jump-to-year works for both BS and AD.
- Filters can be changed repeatedly without getting stuck.
- BS month filtering appears only when month-level data exists, preventing non-functional month controls.
- Saved-only view toggles correctly and restores normal timeline when disabled.
- Opening an event deep-links using `?event=<id>`.
- Browser refresh keeps saved events + last state.
- Large event lists scroll without rendering all 5,900+ cards at once.
- Event detail sources only produce links for HTTP/HTTPS URLs.
- Reduced-motion OS setting removes unnecessary animated background.

## 9. Important integration note for the existing M1–M8 issue

This bundle deliberately keeps filter state independent from timeline position and derives scrolling from the filtered event array. If M1–M8 are existing Miti controls outside this module, wire them to `filters` (or add a dedicated `monthBS` filter) rather than manipulating pixel scroll offsets. That removes the common stale-index / wrong-scroll-position failure mode.

## 10. Rollback

All new runtime code is isolated under:

```text
features/time-machine/
server/time-machine/
app/api/time-machine/
app/time-machine/
```

Rollback is therefore one route/module removal plus restoration of the old launcher/import.
