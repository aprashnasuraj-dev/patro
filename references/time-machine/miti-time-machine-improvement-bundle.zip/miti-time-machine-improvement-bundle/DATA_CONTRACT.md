# Time Machine Data Contract

The UI is intentionally independent of storage technology. Production data only needs to satisfy the `HistoricalEvent` shape.

## Required
- `id`: stable unique string. Never regenerate IDs on every deployment.
- `yearAD`: integer used for chronological sorting.
- `title`: Nepali or canonical display title.
- `summary`: short card text.
- `era`: `ancient | medieval | early-modern | modern | contemporary`.
- `category`: canonical category.

## Strongly recommended
- `yearBS`
- `monthBS`, `dayBS` where historically known
- `titleEn`
- `details`
- `region`, `place`
- `tags`
- `disputed`, `confidence`
- `sources[]` with label and URL/publisher/year when available

## Precision rule
Do not invent a month/day for records that are only known to a year. Omit the field instead.

## Disputed records
Keep the record discoverable but set:

```json
{
  "disputed": true,
  "confidence": "low",
  "sources": [
    { "label": "Source A", "url": "https://...", "note": "Claims ..." },
    { "label": "Source B", "url": "https://...", "note": "Disagrees ..." }
  ]
}
```

The UI marks it as disputed instead of hiding it.

## Month filtering
The toolbar exposes BS month filtering only when at least one dataset record contains `monthBS`. This prevents dead M1–M12 controls on year-only datasets.
