# Change Log — Time Machine v2

## Fixed
- Eliminated approximate year-to-pixel mapping.
- Eliminated duplicate ambient audio hook ownership.
- Added animation frame cleanup and viewport resizing for particles.
- Added stable unique event IDs instead of year+title React keys.
- Added data validation for duplicate IDs and malformed records.
- Removed hard dependency on Framer Motion/Howler from the module.

## Added
- 5,900+ record friendly virtualized timeline.
- Nepali + English search and Devanagari digit normalization.
- BS/AD jump-to-year.
- Era/category/region/disputed filters.
- Detail-on-demand API route.
- Structured source handling with URL protocol safety.
- Deep links, favorites, state persistence, responsive layout, reduced motion.
- JSON repository cache invalidated by file modification time.
- Conversion, validation and test scripts.

## Not included
- A verified replacement 5,900+ historical dataset, because no full production event database was provided with the source document.
- Proprietary/licensed audio assets.
