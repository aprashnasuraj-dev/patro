import fs from 'node:fs/promises';
import path from 'node:path';
import type { EventIndexItem, EventIndexResponse, HistoricalEvent } from '../../features/time-machine/types';

const DATA_FILE = process.env.TIME_MACHINE_DATA_FILE
  ? path.resolve(process.cwd(), process.env.TIME_MACHINE_DATA_FILE)
  : path.join(process.cwd(), 'data', 'time-machine', 'events.json');

let cached: { mtimeMs: number; events: HistoricalEvent[]; byId: Map<string, HistoricalEvent>; index: EventIndexResponse } | null = null;

function compact(event: HistoricalEvent): EventIndexItem {
  return {
    id: event.id,
    yearBS: event.yearBS,
    yearAD: event.yearAD,
    monthBS: event.monthBS,
    dayBS: event.dayBS,
    title: event.title,
    titleEn: event.titleEn,
    summary: event.summary,
    era: event.era,
    category: event.category,
    tags: event.tags,
    region: event.region,
    place: event.place,
    disputed: event.disputed,
    confidence: event.confidence,
    importance: event.importance,
  };
}

function naturalSort(values: Iterable<string | undefined>): string[] {
  return [...new Set([...values].filter((v): v is string => Boolean(v)))].sort((a, b) => a.localeCompare(b, 'ne'));
}

function buildIndex(events: HistoricalEvent[], mtimeMs: number): EventIndexResponse {
  const sorted = [...events].sort((a, b) => {
    if (a.yearAD !== b.yearAD) return a.yearAD - b.yearAD;
    return (a.monthAD ?? 0) - (b.monthAD ?? 0) || (a.dayAD ?? 0) - (b.dayAD ?? 0) || a.title.localeCompare(b.title, 'ne');
  });

  const adYears = sorted.map((event) => event.yearAD).filter(Number.isFinite);
  const bsYears = sorted.map((event) => event.yearBS).filter((v): v is number => Number.isFinite(v));

  return {
    version: `mtime-${Math.floor(mtimeMs)}`,
    generatedAt: new Date(mtimeMs).toISOString(),
    total: sorted.length,
    events: sorted.map(compact),
    facets: {
      eras: naturalSort(sorted.map((event) => event.era)),
      categories: naturalSort(sorted.map((event) => event.category)),
      regions: naturalSort(sorted.map((event) => event.region)),
      monthsBS: [...new Set(sorted.map((event) => event.monthBS).filter((v): v is number => Number.isInteger(v) && v >= 1 && v <= 12))].sort((a, b) => a - b),
      yearAD: adYears.length ? { min: Math.min(...adYears), max: Math.max(...adYears) } : null,
      yearBS: bsYears.length ? { min: Math.min(...bsYears), max: Math.max(...bsYears) } : null,
    },
  };
}

async function load() {
  const stat = await fs.stat(DATA_FILE);
  if (cached && cached.mtimeMs === stat.mtimeMs) return cached;

  const raw = await fs.readFile(DATA_FILE, 'utf8');
  const parsed = JSON.parse(raw) as HistoricalEvent[];
  if (!Array.isArray(parsed)) throw new Error('Time Machine dataset must be a JSON array.');

  const byId = new Map<string, HistoricalEvent>();
  for (const event of parsed) {
    if (!event.id || !event.title || !Number.isFinite(event.yearAD)) {
      throw new Error(`Invalid time-machine event: ${JSON.stringify(event).slice(0, 180)}`);
    }
    if (byId.has(event.id)) throw new Error(`Duplicate time-machine event id: ${event.id}`);
    byId.set(event.id, event);
  }

  cached = {
    mtimeMs: stat.mtimeMs,
    events: parsed,
    byId,
    index: buildIndex(parsed, stat.mtimeMs),
  };
  return cached;
}

export async function getEventIndex(): Promise<EventIndexResponse> {
  return (await load()).index;
}

export async function getEventById(id: string): Promise<HistoricalEvent | null> {
  return (await load()).byId.get(id) ?? null;
}

export async function getDatasetPath(): Promise<string> {
  return DATA_FILE;
}
