import {N,S,D,ODate,addDays,Q,M,P,R} from '../_vendor/guard';
import type {Result} from '../_vendor/guard';
/** Pure, bounded calculations; no user-data storage or network. */
export function calculate(i:Record<string,unknown>):Result {
const state=S(i,'state',100),required=N(i,'required',1,40000),accepted=N(i,'logged',0,40000),raw=S(i,'entries',4000),cap=N(i,'dailyCap',1,24);if(!state)throw Error('Enter trade and board');const lines=raw.trim().split(/
?
/).filter(Boolean);if(!lines.length||lines.length>120)throw Error('Provide 1–120 new log entries');let fresh=0,field=0,classroom=0;const daily=new Map<string,number>();for(const [j,line] of lines.entries()){const p=line.split(',');if(p.length!==3)throw Error(`Log ${j+1}: date,hours,type`);const date=D({date:p[0].trim()},'date'),h=Number(p[1]),type=p[2].trim();if(!Number.isFinite(h)||h<=0||h>cap||!['field','classroom'].includes(type))throw Error(`Log ${j+1}: invalid hours/category`);daily.set(date,(daily.get(date)||0)+h);if((daily.get(date)||0)>cap)throw Error(`Log ${j+1}: per-day cap exceeded`);fresh+=h;if(type==='field')field+=h;else classroom+=h;}
 return R([{label:'Potential counted hours (unapproved)',value:Q(accepted+fresh)},{label:'New field hours',value:Q(field)},{label:'New classroom hours',value:Q(classroom)},{label:'Target deficit if approved',value:Q(Math.max(0,required-accepted-fresh))}],[`Only ${state}'s licensing authority can accept documented hours. Classroom field-work splits and applicable caps may disqualify entries.`, 'Entries are local proposed records, not notarized or supervisor-certified experience.'],['Potential total = previously accepted hours + current entries, subject to approval.']);
}
